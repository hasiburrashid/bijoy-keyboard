package com.bijoykb.keyboard;

import android.content.SharedPreferences;
import android.inputmethodservice.InputMethodService;
import android.view.KeyEvent;
import android.view.View;
import android.view.inputmethod.EditorInfo;
import android.view.inputmethod.InputConnection;
import android.view.inputmethod.InputMethodManager;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.nio.charset.Charset;
import java.util.ArrayList;
import java.util.List;

public class BijoyIME extends InputMethodService implements BijoyKeyboardView.Listener {

    private static final String PREFS = "bijoy_prefs";
    private static final String KEY_LAYOUT = "layout";

    private BijoyKeyboardView view;
    private final BijoyEngine[] engines = new BijoyEngine[2];
    private int layout = 0;
    private SharedPreferences prefs;

    @Override
    public void onCreate() {
        super.onCreate();
        prefs = getSharedPreferences(PREFS, MODE_PRIVATE);
        layout = prefs.getInt(KEY_LAYOUT, 0) == 1 ? 1 : 0;
        engines[0] = new BijoyEngine(loadMap("conj-2003.txt"));
        engines[1] = new BijoyEngine(loadMap("conj-classic.txt"));
    }

    private List<String[]> loadMap(String asset) {
        try {
            InputStream in = getAssets().open(asset);
            BufferedReader r = new BufferedReader(new InputStreamReader(in, Charset.forName("UTF-8")));
            try {
                return BijoyEngine.parseMap(r);
            } finally {
                r.close();
            }
        } catch (IOException e) {
            return new ArrayList<String[]>();
        }
    }

    private BijoyEngine engine() { return engines[layout]; }

    @Override
    public View onCreateInputView() {
        view = new BijoyKeyboardView(this);
        view.setListener(this);
        view.setLayoutIndex(layout);
        return view;
    }

    @Override
    public boolean onEvaluateFullscreenMode() { return false; }

    @Override
    public void onStartInputView(EditorInfo info, boolean restarting) {
        super.onStartInputView(info, restarting);
        engine().reset();
        if (view != null) {
            view.setLayoutIndex(layout);
            view.resetState();
        }
    }

    @Override
    public void onFinishInput() {
        super.onFinishInput();
        engines[0].reset();
        engines[1].reset();
    }

    // ------------------------------------------------------------ editing helpers

    private void applyEdit(InputConnection ic, BijoyEngine.Edit e) {
        if (e == null) return;
        ic.beginBatchEdit();
        if (e.delete > 0) ic.deleteSurroundingText(e.delete, 0);
        if (e.insert.length() > 0) ic.commitText(e.insert, 1);
        ic.endBatchEdit();
    }

    /** If the text before the cursor no longer matches what we wrote, forget our state. */
    private void verify(InputConnection ic) {
        String cur = engine().currentAscii();
        if (cur.length() == 0) return;
        CharSequence t = ic.getTextBeforeCursor(cur.length(), 0);
        if (t == null || !cur.equals(t.toString())) engine().reset();
    }

    private boolean deleteSelection(InputConnection ic) {
        CharSequence sel = ic.getSelectedText(0);
        if (sel != null && sel.length() > 0) {
            ic.commitText("", 1);
            engine().reset();
            return true;
        }
        return false;
    }

    // ------------------------------------------------------------ listener

    @Override
    public void onText(String s) {
        InputConnection ic = getCurrentInputConnection();
        if (ic == null) return;
        deleteSelection(ic);
        verify(ic);
        applyEdit(ic, engine().onKey(s));
    }

    @Override
    public void onBackspace() {
        InputConnection ic = getCurrentInputConnection();
        if (ic == null) return;
        if (deleteSelection(ic)) return;
        for (int guard = 0; guard < 4; guard++) {
            String ins = engine().peekInserted();
            if (ins == null) break;
            CharSequence t = ic.getTextBeforeCursor(ins.length(), 0);
            if (t == null || !ins.equals(t.toString())) {
                engine().reset();
                break;
            }
            BijoyEngine.Edit e = engine().onBackspace();
            if (e == null) break;
            if (e.delete == 0 && e.insert.length() == 0) continue;
            applyEdit(ic, e);
            return;
        }
        sendDownUpKeyEvents(KeyEvent.KEYCODE_DEL);
    }

    @Override
    public void onEnter() {
        InputConnection ic = getCurrentInputConnection();
        if (ic == null) return;
        engine().reset();
        EditorInfo ei = getCurrentInputEditorInfo();
        if (ei != null) {
            int action = ei.imeOptions & EditorInfo.IME_MASK_ACTION;
            boolean noEnterAction = (ei.imeOptions & EditorInfo.IME_FLAG_NO_ENTER_ACTION) != 0;
            if (!noEnterAction && action != EditorInfo.IME_ACTION_NONE
                    && action != EditorInfo.IME_ACTION_UNSPECIFIED) {
                ic.performEditorAction(action);
                return;
            }
        }
        sendDownUpKeyEvents(KeyEvent.KEYCODE_ENTER);
    }

    private void setLayout(int l) {
        if (l == layout) return;
        engine().reset();
        layout = l;
        engine().reset();
        prefs.edit().putInt(KEY_LAYOUT, layout).apply();
        if (view != null) view.setLayoutIndex(layout);
    }

    @Override
    public void onGlobeTap() { setLayout(1 - layout); }

    @Override
    public void onGlobeLong() { onPickerRequest(); }

    @Override
    public void onLayoutPick(int l) { setLayout(l == 1 ? 1 : 0); }

    @Override
    public void onPickerRequest() {
        InputMethodManager imm = (InputMethodManager) getSystemService(INPUT_METHOD_SERVICE);
        if (imm != null) imm.showInputMethodPicker();
    }
}
