package com.bijoykb.keyboard;

import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.SharedPreferences;
import android.inputmethodservice.InputMethodService;
import android.text.InputType;
import android.view.KeyEvent;
import android.view.View;
import android.view.inputmethod.EditorInfo;
import android.view.inputmethod.InputConnection;
import android.view.inputmethod.InputMethodManager;

import org.json.JSONArray;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.nio.charset.Charset;
import java.util.ArrayList;
import java.util.List;

public class BijoyIME extends InputMethodService implements BijoyKeyboardView.Listener {

    private static final String PREFS = "bijoy_prefs";
    private static final String KEY_LAYOUT = "layout4";
    private static final String KEY_CLIPS = "clips";
    private static final int LAYOUT_COUNT = 4;
    private static final int MAX_CLIPS = 30;

    private BijoyKeyboardView view;
    private final BijoyEngine[] engines = new BijoyEngine[LAYOUT_COUNT];
    private int layout = 0;
    private SharedPreferences prefs;
    private ClipboardManager clipboard;
    private final List<String> clips = new ArrayList<String>();

    private final ClipboardManager.OnPrimaryClipChangedListener clipListener =
            new ClipboardManager.OnPrimaryClipChangedListener() {
                @Override public void onPrimaryClipChanged() { captureClip(); }
            };

    @Override
    public void onCreate() {
        super.onCreate();
        prefs = getSharedPreferences(PREFS, MODE_PRIVATE);
        int saved = prefs.getInt(KEY_LAYOUT, 0);
        layout = (saved >= 0 && saved < LAYOUT_COUNT) ? saved : 0;
        List<String[]> empty = new ArrayList<String[]>();
        engines[0] = new BijoyEngine(empty, true);                       // Bijoy Unicode
        engines[1] = new BijoyEngine(loadMap("conj-2003.txt"), loadMap("finish-2003.txt"), false);   // Bijoy 2003 (ASCII)
        engines[2] = new BijoyEngine(loadMap("conj-classic.txt"), loadMap("finish-classic.txt"), false); // Bijoy Classic (ASCII)
        engines[3] = new BijoyEngine(empty, true);                       // English
        loadClips();
        try {
            clipboard = (ClipboardManager) getSystemService(CLIPBOARD_SERVICE);
            if (clipboard != null) clipboard.addPrimaryClipChangedListener(clipListener);
        } catch (Exception e) {
            clipboard = null;
        }
    }

    @Override
    public void onDestroy() {
        if (clipboard != null) {
            try { clipboard.removePrimaryClipChangedListener(clipListener); } catch (Exception e) { }
        }
        super.onDestroy();
    }

    private List<String[]> loadMap(String asset) {
        try {
            InputStream in = getAssets().open(asset);
            BufferedReader r = new BufferedReader(new InputStreamReader(in, Charset.forName("UTF-8")));
            try {
                return BijoyEngine.parseMap(r);
            } finally {
                r.close();
            }
        } catch (IOException e) {
            return new ArrayList<String[]>();
        }
    }

    private BijoyEngine engine() { return engines[layout]; }

    @Override
    public View onCreateInputView() {
        view = new BijoyKeyboardView(this);
        view.setListener(this);
        view.setLabelEngine(engines[1]);
        view.setLayoutIndex(layout);
        view.setClips(clips);
        updatePreview();
        return view;
    }

    @Override
    public boolean onEvaluateFullscreenMode() { return false; }

    @Override
    public void onStartInputView(EditorInfo info, boolean restarting) {
        super.onStartInputView(info, restarting);
        for (BijoyEngine e : engines) e.reset();
        captureClip();
        if (view != null) {
            view.setLayoutIndex(layout);
            view.resetState();
            view.setClips(clips);
        }
        updatePreview();
    }

    @Override
    public void onFinishInput() {
        super.onFinishInput();
        for (BijoyEngine e : engines) e.reset();
        updatePreview();
    }

    private void updatePreview() {
        if (view != null) view.setPreview(engine().preview());
    }

    // ------------------------------------------------------------ clipboard history

    private void loadClips() {
        clips.clear();
        String json = prefs.getString(KEY_CLIPS, null);
        if (json == null) return;
        try {
            JSONArray a = new JSONArray(json);
            for (int i = 0; i < a.length() && i < MAX_CLIPS; i++) clips.add(a.getString(i));
        } catch (Exception e) {
            clips.clear();
        }
    }

    private void saveClips() {
        JSONArray a = new JSONArray();
        for (String s : clips) a.put(s);
        prefs.edit().putString(KEY_CLIPS, a.toString()).apply();
    }

    private void captureClip() {
        if (clipboard == null) return;
        try {
            ClipData d = clipboard.getPrimaryClip();
            if (d == null || d.getItemCount() == 0) return;
            if (d.getDescription() != null && d.getDescription().getExtras() != null
                    && d.getDescription().getExtras().getBoolean("android.content.extra.IS_SENSITIVE")) {
                return;
            }
            CharSequence t = d.getItemAt(0).coerceToText(this);
            if (t == null) return;
            String s = t.toString();
            if (s.trim().length() == 0) return;
            if (s.length() > 3000) s = s.substring(0, 3000);
            if (!clips.isEmpty() && clips.get(0).equals(s)) return;
            clips.remove(s);
            clips.add(0, s);
            while (clips.size() > MAX_CLIPS) clips.remove(clips.size() - 1);
            saveClips();
            if (view != null) view.setClips(clips);
        } catch (Exception e) {
            // clipboard not readable right now
        }
    }

    @Override
    public void onClipPaste(String t) {
        InputConnection ic = getCurrentInputConnection();
        if (ic == null || t == null) return;
        deleteSelection(ic);
        engine().reset();
        ic.commitText(t, 1);
        updatePreview();
    }

    @Override
    public void onClipDelete(int index) {
        if (index >= 0 && index < clips.size()) {
            clips.remove(index);
            saveClips();
            if (view != null) view.setClips(clips);
        }
    }

    @Override
    public void onClipClear() {
        clips.clear();
        saveClips();
        if (view != null) view.setClips(clips);
    }

    // ------------------------------------------------------------ editing helpers

    private void applyEdit(InputConnection ic, BijoyEngine.Edit e) {
        if (e == null) return;
        ic.beginBatchEdit();
        if (e.delete > 0) ic.deleteSurroundingText(e.delete, 0);
        if (e.insert.length() > 0) ic.commitText(e.insert, 1);
        ic.endBatchEdit();
    }

    /** If the text before the cursor no longer matches what we wrote, forget our state. */
    private void verify(InputConnection ic) {
        String cur = engine().currentAscii();
        if (cur.length() == 0) return;
        CharSequence t = ic.getTextBeforeCursor(cur.length(), 0);
        if (t == null || !cur.equals(t.toString())) engine().reset();
    }

    private boolean deleteSelection(InputConnection ic) {
        CharSequence sel = ic.getSelectedText(0);
        if (sel != null && sel.length() > 0) {
            ic.commitText("", 1);
            engine().reset();
            return true;
        }
        return false;
    }

    // ------------------------------------------------------------ listener

    /** Verify our state against the editor and tell the engine what char precedes the syllable. */
    private void prepare(InputConnection ic) {
        verify(ic);
        if (engine().currentAscii().length() == 0) {
            CharSequence b = ic.getTextBeforeCursor(1, 0);
            engine().setLeft(b == null ? "" : b.toString());
        }
    }

    @Override
    public void onText(String s) {
        InputConnection ic = getCurrentInputConnection();
        if (ic == null) return;
        deleteSelection(ic);
        if ("\t".equals(s)) {
            engine().reset();
            EditorInfo ei = getCurrentInputEditorInfo();
            boolean multi = ei != null && (ei.inputType & InputType.TYPE_TEXT_FLAG_MULTI_LINE) != 0;
            if (multi) ic.commitText("\t", 1);
            else sendDownUpKeyEvents(KeyEvent.KEYCODE_TAB);
            updatePreview();
            return;
        }
        prepare(ic);
        applyEdit(ic, engine().onKey(s));
        updatePreview();
    }

    /** Quick double tap on a letter key: replace the letter just typed by its shift letter. */
    @Override
    public void onReplaceWithShift(String out) {
        InputConnection ic = getCurrentInputConnection();
        if (ic == null) return;
        deleteSelection(ic);
        verify(ic);
        String ins = engine().peekInserted();
        if (ins != null) {
            CharSequence t = ic.getTextBeforeCursor(ins.length(), 0);
            if (t != null && ins.equals(t.toString())) {
                applyEdit(ic, engine().onBackspace());
            } else {
                engine().reset();
            }
        }
        prepare(ic);
        applyEdit(ic, engine().onKey(out));
        updatePreview();
    }

    @Override
    public void onEditAction(int action) {
        InputConnection ic = getCurrentInputConnection();
        if (ic == null) return;
        int id = action == BijoyKeyboardView.A_COPY ? android.R.id.copy
                : action == BijoyKeyboardView.A_CUT ? android.R.id.cut : android.R.id.paste;
        ic.performContextMenuAction(id);
        engine().reset();
        updatePreview();
    }

    private boolean volumeCursor() { return prefs.getBoolean("vol_cursor", true); }

    private static boolean isVolumeKey(int keyCode) {
        return keyCode == KeyEvent.KEYCODE_VOLUME_UP || keyCode == KeyEvent.KEYCODE_VOLUME_DOWN;
    }

    @Override
    public boolean onKeyDown(int keyCode, KeyEvent event) {
        if (isVolumeKey(keyCode) && volumeCursor() && isInputViewShown()) {
            engine().reset();
            updatePreview();
            sendDownUpKeyEvents(keyCode == KeyEvent.KEYCODE_VOLUME_UP
                    ? KeyEvent.KEYCODE_DPAD_RIGHT : KeyEvent.KEYCODE_DPAD_LEFT);
            return true;
        }
        return super.onKeyDown(keyCode, event);
    }

    @Override
    public boolean onKeyUp(int keyCode, KeyEvent event) {
        if (isVolumeKey(keyCode) && volumeCursor() && isInputViewShown()) return true;
        return super.onKeyUp(keyCode, event);
    }

    @Override
    public void onBackspace() {
        InputConnection ic = getCurrentInputConnection();
        if (ic == null) return;
        if (deleteSelection(ic)) {
            updatePreview();
            return;
        }
        for (int guard = 0; guard < 4; guard++) {
            String ins = engine().peekInserted();
            if (ins == null) break;
            CharSequence t = ic.getTextBeforeCursor(ins.length(), 0);
            if (t == null || !ins.equals(t.toString())) {
                engine().reset();
                break;
            }
            BijoyEngine.Edit e = engine().onBackspace();
            if (e == null) break;
            if (e.delete == 0 && e.insert.length() == 0) continue;
            applyEdit(ic, e);
            updatePreview();
            return;
        }
        sendDownUpKeyEvents(KeyEvent.KEYCODE_DEL);
        updatePreview();
    }

    @Override
    public void onEnter() {
        InputConnection ic = getCurrentInputConnection();
        if (ic == null) return;
        engine().reset();
        updatePreview();
        EditorInfo ei = getCurrentInputEditorInfo();
        if (ei != null) {
            int action = ei.imeOptions & EditorInfo.IME_MASK_ACTION;
            boolean noEnterAction = (ei.imeOptions & EditorInfo.IME_FLAG_NO_ENTER_ACTION) != 0;
            if (!noEnterAction && action != EditorInfo.IME_ACTION_NONE
                    && action != EditorInfo.IME_ACTION_UNSPECIFIED) {
                ic.performEditorAction(action);
                return;
            }
        }
        sendDownUpKeyEvents(KeyEvent.KEYCODE_ENTER);
    }

    private void setLayout(int l) {
        if (l == layout) return;
        engine().reset();
        layout = l;
        engine().reset();
        prefs.edit().putInt(KEY_LAYOUT, layout).apply();
        if (view != null) view.setLayoutIndex(layout);
        updatePreview();
    }

    @Override
    public void onGlobeTap() { setLayout((layout + 1) % LAYOUT_COUNT); }

    @Override
    public void onGlobeLong() { onPickerRequest(); }

    @Override
    public void onPickerRequest() {
        InputMethodManager imm = (InputMethodManager) getSystemService(INPUT_METHOD_SERVICE);
        if (imm != null) imm.showInputMethodPicker();
    }
}
