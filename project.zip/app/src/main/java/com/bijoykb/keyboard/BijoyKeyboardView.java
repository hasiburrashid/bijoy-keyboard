package com.bijoykb.keyboard;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.RectF;
import android.graphics.Typeface;
import android.os.Handler;
import android.os.Looper;
import android.util.SparseArray;
import android.view.HapticFeedbackConstants;
import android.view.MotionEvent;
import android.view.View;

import java.util.ArrayList;
import java.util.List;

/** Ridmik-style keyboard drawn on a canvas: toolbar, number row, 3 letter rows, bottom row. */
public class BijoyKeyboardView extends View {

    public interface Listener {
        void onText(String s);
        void onBackspace();
        void onEnter();
        void onGlobeTap();
        void onGlobeLong();
        void onLayoutPick(int layout);
        void onPickerRequest();
    }

    private static final int T_TEXT = 0, T_SHIFT = 1, T_BACK = 2, T_ENTER = 3, T_GLOBE = 4,
            T_SYM = 5, T_ABC = 6, T_SPACE = 7;
    private static final int SHIFT_OFF = 0, SHIFT_ON = 1, SHIFT_LOCK = 2;
    private static final int PAGE_LETTERS = 0, PAGE_SYMBOLS = 1;

    private static final int COL_BG = 0xFF1B1B1B;
    private static final int COL_KEY = 0xFF4A4A4A;
    private static final int COL_KEY_SPECIAL = 0xFF2F2F2F;
    private static final int COL_KEY_PRESSED = 0xFF707070;
    private static final int COL_ACCENT = 0xFF2E7D5B;
    private static final int COL_TEXT = 0xFFFFFFFF;
    private static final int COL_HINT = 0xFFB4B4B4;

    private static final class Key {
        int type;
        String out, shiftOut, label, shiftLabel;
        String[] extras;
        float weight = 1f;
        final RectF rect = new RectF();
        final RectF hit = new RectF();
    }

    private static final class Ptr {
        Key key;
        int chip = -1;
        boolean popup, longFired;
        int sel = -1;
        List<String[]> items;
        final RectF popupRect = new RectF();
        Runnable longPress, repeat;
    }

    private Listener listener;
    private final List<Key[]> letters = new ArrayList<Key[]>();
    private final List<Key[]> symbols = new ArrayList<Key[]>();
    private int page = PAGE_LETTERS;
    private int shiftState = SHIFT_OFF;
    private long lastShiftTap = 0;
    private int layoutIndex = 0;

    private final Paint fill = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint text = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint stroke = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final RectF tmp = new RectF();
    private final RectF[] chipRects = {new RectF(), new RectF(), new RectF()};
    private final Handler handler = new Handler(Looper.getMainLooper());
    private final SparseArray<Ptr> ptrs = new SparseArray<Ptr>();
    private final float density;
    private final float scaledDensity;

    public BijoyKeyboardView(Context c) {
        super(c);
        density = c.getResources().getDisplayMetrics().density;
        scaledDensity = c.getResources().getDisplayMetrics().scaledDensity;
        text.setTypeface(Typeface.DEFAULT);
        text.setTextAlign(Paint.Align.CENTER);
        stroke.setStyle(Paint.Style.STROKE);
        stroke.setStrokeCap(Paint.Cap.ROUND);
        stroke.setStrokeJoin(Paint.Join.ROUND);
        buildLayouts();
    }

    public void setListener(Listener l) { listener = l; }

    public void setLayoutIndex(int i) {
        layoutIndex = i;
        invalidate();
    }

    public void resetState() {
        cancelAll();
        shiftState = SHIFT_OFF;
        page = PAGE_LETTERS;
        layoutKeys();
        invalidate();
    }

    // ------------------------------------------------------------------ layouts

    private static Key tk(String out, String shiftOut, String shiftLabel) {
        Key k = new Key();
        k.type = T_TEXT;
        k.out = out;
        k.shiftOut = shiftOut;
        k.shiftLabel = shiftLabel;
        return k;
    }

    private static Key skey(int type, float w, String label) {
        Key k = new Key();
        k.type = type;
        k.weight = w;
        k.label = label;
        return k;
    }

    private static Key[] row(String[] n, String[] s) {
        Key[] r = new Key[n.length];
        for (int i = 0; i < n.length; i++) r[i] = tk(n[i], s[i], null);
        return r;
    }

    private void buildLayouts() {
        String[] digits = {"\u09E7", "\u09E8", "\u09E9", "\u09EA", "\u09EB", "\u09EC", "\u09ED", "\u09EE", "\u09EF", "\u09E6"};
        String[] dshift = {"!", "@", "#", "$", "%", "^", "&", "*", "(", ")"};
        Key[] r0 = row(digits, dshift);
        r0[3].shiftLabel = "\u09F3";

        Key[] r1 = row(new String[] {"\u0999", "\u09AF", "\u09A1", "\u09AA", "\u099F", "\u099A", "\u099C", "\u09B9", "\u0997", "\u09A1\u09BC"},
                new String[] {"\u0982", "\u09AF\u09BC", "\u09A2", "\u09AB", "\u09A0", "\u099B", "\u099D", "\u099E", "\u0998", "\u09A2\u09BC"});
        Key[] r2 = row(new String[] {"\u09C3", "\u09C1", "\u09BF", "\u09BE", "\u09CD", "\u09AC", "\u0995", "\u09A4", "\u09A6", "\u09CE"},
                new String[] {"\u0981", "\u09C2", "\u09C0", "\u0985", "\u0964", "\u09AD", "\u0996", "\u09A5", "\u09A7", "\u0983"});
        Key[] r3letters = row(new String[] {"\u09CD\u09B0", "\u0993", "\u09C7", "\u09B0", "\u09A8", "\u09B8", "\u09AE"},
                new String[] {"\u09CD\u09AF", "\u09D7", "\u09C8", "\u09B2", "\u09A3", "\u09B7", "\u09B6"});
        Key[] r3 = new Key[r3letters.length + 2];
        r3[0] = skey(T_SHIFT, 1.5f, null);
        System.arraycopy(r3letters, 0, r3, 1, r3letters.length);
        r3[r3.length - 1] = skey(T_BACK, 1.5f, null);

        Key comma = tk(",", null, null);
        comma.extras = new String[] {".", "?", "!", ":", ";"};
        Key danda = tk("\u0964", null, null);
        danda.extras = new String[] {".", "?", "!"};
        Key space = skey(T_SPACE, 3.9f, null);
        space.out = " ";
        Key[] r4 = {skey(T_SYM, 1.5f, "?123"), skey(T_GLOBE, 1.1f, null), comma, space, danda,
                skey(T_ENTER, 1.5f, null)};

        letters.add(r0);
        letters.add(r1);
        letters.add(r2);
        letters.add(r3);
        letters.add(r4);

        // symbols page
        Key[] s0 = row(digits, dshift);
        s0[3].shiftLabel = "\u09F3";
        for (Key k : s0) { k.shiftOut = null; k.shiftLabel = null; }
        Key[] s1 = symRow("!@#$%^&*()");
        Key[] s2 = symRow("-_=+[]{};:");
        Key[] s3m = symRow("/?|'\"<>");
        Key[] s3 = new Key[s3m.length + 2];
        s3[0] = symKey("~", 1.5f);
        System.arraycopy(s3m, 0, s3, 1, s3m.length);
        s3[s3.length - 1] = skey(T_BACK, 1.5f, null);
        Key dot = tk(".", null, null);
        Key comma2 = tk(",", null, null);
        Key space2 = skey(T_SPACE, 3.9f, null);
        space2.out = " ";
        Key[] s4 = {skey(T_ABC, 1.5f, "\u09AC\u09BE\u0982\u09B2\u09BE"), skey(T_GLOBE, 1.1f, null), comma2, space2, dot,
                skey(T_ENTER, 1.5f, null)};
        symbols.add(s0);
        symbols.add(s1);
        symbols.add(s2);
        symbols.add(s3);
        symbols.add(s4);
    }

    private static Key symKey(String ch, float w) {
        Key k = tk(ch, null, null);
        k.weight = w;
        return k;
    }

    private static Key[] symRow(String chars) {
        Key[] r = new Key[chars.length()];
        for (int i = 0; i < r.length; i++) r[i] = tk(chars.substring(i, i + 1), null, null);
        return r;
    }

    private List<Key[]> rows() { return page == PAGE_LETTERS ? letters : symbols; }

    // ------------------------------------------------------------------ geometry

    private float dp(float v) { return v * density; }

    private float sp(float v) { return v * scaledDensity; }

    private float toolbarH() { return dp(42); }

    private float keyH() {
        boolean land = getResources().getDisplayMetrics().widthPixels
                > getResources().getDisplayMetrics().heightPixels;
        return dp(land ? 40 : 50);
    }

    private float gap() { return dp(5); }

    @Override
    protected void onMeasure(int wSpec, int hSpec) {
        int w = MeasureSpec.getSize(wSpec);
        int h = (int) (toolbarH() + 5 * keyH() + 6 * gap() + dp(2));
        setMeasuredDimension(w, h);
    }

    @Override
    protected void onSizeChanged(int w, int h, int ow, int oh) {
        super.onSizeChanged(w, h, ow, oh);
        layoutKeys();
    }

    private void layoutKeys() {
        float w = getWidth();
        if (w <= 0) return;
        float padH = dp(4);
        float g = gap();
        float kh = keyH();
        float y = toolbarH() + g;
        for (Key[] row : rows()) {
            float total = 0;
            for (Key k : row) total += k.weight;
            float usable = w - 2 * padH - g * (row.length - 1);
            float x = padH;
            for (Key k : row) {
                float kw = usable * k.weight / total;
                k.rect.set(x, y, x + kw, y + kh);
                k.hit.set(x - g / 2, y - g / 2, x + kw + g / 2, y + kh + g / 2);
                x += kw + g;
            }
            y += kh + g;
        }
        // toolbar chips
        float cx = dp(8);
        float ch = toolbarH() - dp(10);
        String[] names = {"\u09E8\u09E6\u09E6\u09E9", "\u0995\u09CD\u09B2\u09BE\u09B8\u09BF\u0995"};
        text.setTextSize(sp(14));
        for (int i = 0; i < 2; i++) {
            float tw = text.measureText(names[i]) + dp(24);
            chipRects[i].set(cx, dp(5), cx + tw, dp(5) + ch);
            cx += tw + dp(8);
        }
        text.setTextSize(sp(13));
        String pk = "\u0985\u09A8\u09CD\u09AF \u0995\u09BF\u09AC\u09CB\u09B0\u09CD\u09A1";
        float pw = text.measureText(pk) + dp(24);
        chipRects[2].set(w - dp(8) - pw, dp(5), w - dp(8), dp(5) + ch);
    }

    // ------------------------------------------------------------------ drawing

    private static boolean isCombining(char c) {
        return (c >= '\u09BC' && c <= '\u09CD') || c == '\u09D7' || c == '\u0981';
    }

    private static String face(String s) {
        if (s == null || s.length() == 0) return "";
        if (isCombining(s.charAt(0))) return "\u25CC" + s;
        return s;
    }

    @Override
    protected void onDraw(Canvas canvas) {
        canvas.drawColor(COL_BG);
        drawToolbar(canvas);
        Ptr popupPtr = null;
        for (Key[] row : rows()) {
            for (Key k : row) drawKey(canvas, k);
        }
        for (int i = 0; i < ptrs.size(); i++) {
            Ptr p = ptrs.valueAt(i);
            if (p.popup) popupPtr = p;
        }
        if (popupPtr != null) drawPopup(canvas, popupPtr);
    }

    private void drawToolbar(Canvas canvas) {
        String[] names = {"\u09E8\u09E6\u09E6\u09E9", "\u0995\u09CD\u09B2\u09BE\u09B8\u09BF\u0995", "\u0985\u09A8\u09CD\u09AF \u0995\u09BF\u09AC\u09CB\u09B0\u09CD\u09A1"};
        for (int i = 0; i < 3; i++) {
            RectF r = chipRects[i];
            boolean active = i < 2 && i == layoutIndex;
            fill.setColor(active ? COL_ACCENT : COL_KEY_SPECIAL);
            canvas.drawRoundRect(r, dp(14), dp(14), fill);
            text.setColor(COL_TEXT);
            text.setTextSize(sp(i < 2 ? 14 : 13));
            drawCentered(canvas, names[i], r.centerX(), r.centerY());
        }
    }

    private boolean isPressed(Key k) {
        for (int i = 0; i < ptrs.size(); i++) {
            if (ptrs.valueAt(i).key == k) return true;
        }
        return false;
    }

    private void drawCentered(Canvas canvas, String s, float cx, float cy) {
        Paint.FontMetrics fm = text.getFontMetrics();
        canvas.drawText(s, cx, cy - (fm.ascent + fm.descent) / 2f, text);
    }

    private void drawKey(Canvas canvas, Key k) {
        boolean special = k.type != T_TEXT && k.type != T_SPACE;
        int col = special ? COL_KEY_SPECIAL : COL_KEY;
        if (k.type == T_ENTER) col = COL_ACCENT;
        if (k.type == T_SHIFT && shiftState != SHIFT_OFF) col = COL_KEY;
        if (isPressed(k)) col = COL_KEY_PRESSED;
        fill.setColor(col);
        canvas.drawRoundRect(k.rect, dp(6), dp(6), fill);
        float cx = k.rect.centerX();
        float cy = k.rect.centerY();
        float s = Math.min(k.rect.width(), k.rect.height());
        text.setColor(COL_TEXT);
        stroke.setColor(COL_TEXT);
        stroke.setStrokeWidth(dp(2));
        switch (k.type) {
            case T_TEXT: {
                boolean sh = shiftState != SHIFT_OFF && page == PAGE_LETTERS && k.shiftOut != null;
                String main = sh ? labelOf(k.shiftOut, k.shiftLabel) : face(k.out);
                text.setTextSize(sp(22));
                drawCentered(canvas, main, cx, cy);
                if (page == PAGE_LETTERS && k.shiftOut != null && !sh) {
                    text.setColor(COL_HINT);
                    text.setTextSize(sp(11));
                    text.setTextAlign(Paint.Align.RIGHT);
                    Paint.FontMetrics fm = text.getFontMetrics();
                    canvas.drawText(labelOf(k.shiftOut, k.shiftLabel), k.rect.right - dp(5),
                            k.rect.top + dp(4) - fm.ascent, text);
                    text.setTextAlign(Paint.Align.CENTER);
                }
                break;
            }
            case T_SPACE: {
                text.setColor(COL_HINT);
                text.setTextSize(sp(14));
                drawCentered(canvas, layoutIndex == 0 ? "\u09AC\u09BF\u099C\u09AF\u09BC \u09E8\u09E6\u09E6\u09E9" : "\u09AC\u09BF\u099C\u09AF\u09BC \u0995\u09CD\u09B2\u09BE\u09B8\u09BF\u0995", cx, cy);
                break;
            }
            case T_SYM:
            case T_ABC: {
                text.setTextSize(sp(15));
                drawCentered(canvas, k.label, cx, cy);
                break;
            }
            case T_SHIFT: {
                Path p = new Path();
                float a = s * 0.30f;
                p.moveTo(cx, cy - a);
                p.lineTo(cx + a, cy);
                p.lineTo(cx + a * 0.45f, cy);
                p.lineTo(cx + a * 0.45f, cy + a * 0.9f);
                p.lineTo(cx - a * 0.45f, cy + a * 0.9f);
                p.lineTo(cx - a * 0.45f, cy);
                p.lineTo(cx - a, cy);
                p.close();
                if (shiftState != SHIFT_OFF) {
                    fill.setColor(COL_TEXT);
                    canvas.drawPath(p, fill);
                } else {
                    stroke.setStyle(Paint.Style.STROKE);
                    canvas.drawPath(p, stroke);
                }
                if (shiftState == SHIFT_LOCK) {
                    fill.setColor(COL_ACCENT);
                    canvas.drawRect(cx - a * 0.45f, cy + a * 1.05f, cx + a * 0.45f,
                            cy + a * 1.05f + dp(3), fill);
                }
                break;
            }
            case T_BACK: {
                float a = s * 0.30f;
                Path p = new Path();
                p.moveTo(cx - a * 1.3f, cy);
                p.lineTo(cx - a * 0.5f, cy - a * 0.8f);
                p.lineTo(cx + a * 1.3f, cy - a * 0.8f);
                p.lineTo(cx + a * 1.3f, cy + a * 0.8f);
                p.lineTo(cx - a * 0.5f, cy + a * 0.8f);
                p.close();
                canvas.drawPath(p, stroke);
                canvas.drawLine(cx - a * 0.2f, cy - a * 0.35f, cx + a * 0.7f, cy + a * 0.35f, stroke);
                canvas.drawLine(cx - a * 0.2f, cy + a * 0.35f, cx + a * 0.7f, cy - a * 0.35f, stroke);
                break;
            }
            case T_ENTER: {
                float a = s * 0.26f;
                canvas.drawLine(cx + a, cy - a, cx + a, cy, stroke);
                canvas.drawLine(cx + a, cy, cx - a, cy, stroke);
                canvas.drawLine(cx - a, cy, cx - a * 0.3f, cy - a * 0.7f, stroke);
                canvas.drawLine(cx - a, cy, cx - a * 0.3f, cy + a * 0.7f, stroke);
                break;
            }
            case T_GLOBE: {
                float r = s * 0.28f;
                canvas.drawCircle(cx, cy, r, stroke);
                canvas.drawLine(cx - r, cy, cx + r, cy, stroke);
                tmp.set(cx - r * 0.45f, cy - r, cx + r * 0.45f, cy + r);
                canvas.drawOval(tmp, stroke);
                break;
            }
            default:
                break;
        }
    }

    private static String labelOf(String out, String label) {
        return face(label != null ? label : out);
    }

    private void drawPopup(Canvas canvas, Ptr p) {
        fill.setColor(0xFF3B3B3B);
        tmp.set(p.popupRect);
        tmp.inset(-dp(3), -dp(3));
        canvas.drawRoundRect(tmp, dp(8), dp(8), fill);
        int n = p.items.size();
        float cw = p.popupRect.width() / n;
        for (int i = 0; i < n; i++) {
            if (i == p.sel) {
                fill.setColor(COL_ACCENT);
                tmp.set(p.popupRect.left + i * cw + dp(2), p.popupRect.top,
                        p.popupRect.left + (i + 1) * cw - dp(2), p.popupRect.bottom);
                canvas.drawRoundRect(tmp, dp(6), dp(6), fill);
            }
            text.setColor(COL_TEXT);
            text.setTextSize(sp(22));
            drawCentered(canvas, p.items.get(i)[0], p.popupRect.left + (i + 0.5f) * cw,
                    p.popupRect.centerY());
        }
    }

    // ------------------------------------------------------------------ touch

    @Override
    public boolean onTouchEvent(MotionEvent ev) {
        int action = ev.getActionMasked();
        int idx = ev.getActionIndex();
        switch (action) {
            case MotionEvent.ACTION_DOWN:
            case MotionEvent.ACTION_POINTER_DOWN:
                down(ev.getPointerId(idx), ev.getX(idx), ev.getY(idx));
                break;
            case MotionEvent.ACTION_MOVE:
                for (int i = 0; i < ev.getPointerCount(); i++) {
                    move(ev.getPointerId(i), ev.getX(i), ev.getY(i));
                }
                break;
            case MotionEvent.ACTION_UP:
            case MotionEvent.ACTION_POINTER_UP:
                up(ev.getPointerId(idx), ev.getX(idx), ev.getY(idx));
                break;
            case MotionEvent.ACTION_CANCEL:
                cancelAll();
                invalidate();
                break;
            default:
                break;
        }
        return true;
    }

    private Key hitKey(float x, float y) {
        Key best = null;
        float bestD = Float.MAX_VALUE;
        for (Key[] row : rows()) {
            for (Key k : row) {
                if (k.hit.contains(x, y)) return k;
                float dx = Math.max(Math.max(k.rect.left - x, 0), x - k.rect.right);
                float dy = Math.max(Math.max(k.rect.top - y, 0), y - k.rect.bottom);
                float d = dx * dx + dy * dy;
                if (d < bestD) { bestD = d; best = k; }
            }
        }
        return bestD < dp(14) * dp(14) ? best : null;
    }

    private int hitChip(float x, float y) {
        for (int i = 0; i < 3; i++) {
            if (chipRects[i].contains(x, y)) return i;
        }
        return -1;
    }

    private boolean hasPopup(Key k) {
        return k.type == T_TEXT && (k.shiftOut != null || k.extras != null);
    }

    private void down(final int id, float x, float y) {
        final Ptr p = new Ptr();
        ptrs.put(id, p);
        if (y < toolbarH()) {
            p.chip = hitChip(x, y);
            invalidate();
            return;
        }
        final Key k = hitKey(x, y);
        p.key = k;
        if (k == null) return;
        performHapticFeedback(HapticFeedbackConstants.KEYBOARD_TAP);
        if (k.type == T_BACK) {
            if (listener != null) listener.onBackspace();
            p.repeat = new Runnable() {
                @Override public void run() {
                    if (listener != null) listener.onBackspace();
                    handler.postDelayed(this, 45);
                }
            };
            handler.postDelayed(p.repeat, 400);
        } else if (hasPopup(k) || k.type == T_GLOBE) {
            p.longPress = new Runnable() {
                @Override public void run() { longPressed(p, k); }
            };
            handler.postDelayed(p.longPress, k.type == T_GLOBE ? 500 : 350);
        }
        invalidate();
    }

    private void longPressed(Ptr p, Key k) {
        if (k.type == T_GLOBE) {
            p.longFired = true;
            if (listener != null) listener.onGlobeLong();
            invalidate();
            return;
        }
        List<String[]> items = new ArrayList<String[]>();
        boolean shifted = shiftState != SHIFT_OFF && page == PAGE_LETTERS;
        if (k.shiftOut != null) {
            if (shifted) items.add(new String[] {face(k.out), k.out});
            else items.add(new String[] {labelOf(k.shiftOut, k.shiftLabel), k.shiftOut});
        }
        if (k.extras != null) {
            for (String e : k.extras) items.add(new String[] {e, e});
        }
        if (items.isEmpty()) return;
        p.items = items;
        p.popup = true;
        p.sel = 0;
        float cw = Math.max(dp(46), k.rect.width());
        float total = cw * items.size();
        float left = k.rect.centerX() - total / 2;
        left = Math.max(dp(4), Math.min(left, getWidth() - dp(4) - total));
        float top = Math.max(dp(2), k.rect.top - keyH() - dp(10));
        p.popupRect.set(left, top, left + total, top + keyH());
        performHapticFeedback(HapticFeedbackConstants.LONG_PRESS);
        invalidate();
    }

    private void move(int id, float x, float y) {
        Ptr p = ptrs.get(id);
        if (p == null) return;
        if (p.popup) {
            float cw = p.popupRect.width() / p.items.size();
            int i = (int) Math.floor((x - p.popupRect.left) / cw);
            i = Math.max(0, Math.min(p.items.size() - 1, i));
            if (i != p.sel) {
                p.sel = i;
                invalidate();
            }
        } else if (p.key != null && !p.key.hit.contains(x, y)) {
            if (p.longPress != null) handler.removeCallbacks(p.longPress);
        }
    }

    private void up(int id, float x, float y) {
        Ptr p = ptrs.get(id);
        ptrs.remove(id);
        if (p == null) return;
        if (p.longPress != null) handler.removeCallbacks(p.longPress);
        if (p.repeat != null) handler.removeCallbacks(p.repeat);
        if (p.chip >= 0) {
            if (hitChip(x, y) == p.chip && listener != null) {
                if (p.chip < 2) listener.onLayoutPick(p.chip);
                else listener.onPickerRequest();
            }
            invalidate();
            return;
        }
        Key k = p.key;
        if (k != null) {
            if (p.popup) {
                if (p.sel >= 0) emitText(p.items.get(p.sel)[1]);
            } else if (!p.longFired && k.type != T_BACK && k.hit.contains(x, y)) {
                tap(k);
            }
        }
        invalidate();
    }

    private void cancelAll() {
        for (int i = 0; i < ptrs.size(); i++) {
            Ptr p = ptrs.valueAt(i);
            if (p.longPress != null) handler.removeCallbacks(p.longPress);
            if (p.repeat != null) handler.removeCallbacks(p.repeat);
        }
        ptrs.clear();
    }

    private void emitText(String out) {
        if (listener != null) listener.onText(out);
        if (shiftState == SHIFT_ON) shiftState = SHIFT_OFF;
    }

    private void tap(Key k) {
        switch (k.type) {
            case T_TEXT: {
                boolean sh = shiftState != SHIFT_OFF && page == PAGE_LETTERS && k.shiftOut != null;
                emitText(sh ? k.shiftOut : k.out);
                break;
            }
            case T_SPACE:
                if (listener != null) listener.onText(" ");
                if (shiftState == SHIFT_ON) shiftState = SHIFT_OFF;
                break;
            case T_SHIFT: {
                long now = System.currentTimeMillis();
                if (shiftState == SHIFT_OFF) {
                    shiftState = SHIFT_ON;
                } else if (shiftState == SHIFT_ON && now - lastShiftTap < 400) {
                    shiftState = SHIFT_LOCK;
                } else {
                    shiftState = SHIFT_OFF;
                }
                lastShiftTap = now;
                break;
            }
            case T_ENTER:
                if (listener != null) listener.onEnter();
                break;
            case T_GLOBE:
                if (listener != null) listener.onGlobeTap();
                break;
            case T_SYM:
                page = PAGE_SYMBOLS;
                layoutKeys();
                break;
            case T_ABC:
                page = PAGE_LETTERS;
                layoutKeys();
                break;
            default:
                break;
        }
    }
}
