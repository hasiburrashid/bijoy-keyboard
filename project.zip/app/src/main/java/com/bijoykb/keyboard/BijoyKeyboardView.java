package com.bijoykb.keyboard;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.Rect;
import android.graphics.RectF;
import android.graphics.Typeface;
import android.os.Handler;
import android.os.Looper;
import android.util.SparseArray;
import android.view.HapticFeedbackConstants;
import android.view.MotionEvent;
import android.view.View;

import java.util.ArrayList;
import java.util.List;

/**
 * Ridmik-style keyboard drawn on a canvas. Layouts: 0 Bijoy Unicode, 1 Bijoy 2003,
 * 2 Bijoy Classic, 3 English. Pages: letters, two symbol pages, number pad, clipboard.
 */
public class BijoyKeyboardView extends View {

    public interface Listener {
        void onText(String s);
        void onBackspace();
        void onEnter();
        void onGlobeTap();
        void onGlobeLong();
        void onPickerRequest();
        void onClipPaste(String text);
        void onClipDelete(int index);
        void onClipClear();
    }

    public static final int L_UNI = 0, L_2003 = 1, L_CLASSIC = 2, L_ENG = 3;

    private static final int T_TEXT = 0, T_SHIFT = 1, T_BACK = 2, T_ENTER = 3, T_GLOBE = 4,
            T_SYM = 5, T_ABC = 6, T_SPACE = 7, T_PAD = 8, T_SYM2 = 9, T_SYM1 = 10;
    private static final int SHIFT_OFF = 0, SHIFT_ON = 1, SHIFT_LOCK = 2;
    private static final int P_MAIN = 0, P_SYM1 = 1, P_SYM2 = 2, P_NUM = 3, P_CLIP = 4;

    private static final int COL_BG = 0xFF1B1B1B;
    private static final int COL_KEY = 0xFF4A4A4A;
    private static final int COL_KEY_DARK = 0xFF2F2F2F;
    private static final int COL_KEY_PRESSED = 0xFF707070;
    private static final int COL_ACCENT = 0xFF2E7D5B;
    private static final int COL_TEXT = 0xFFFFFFFF;
    private static final int COL_HINT = 0xFFB4B4B4;

    private static final class Key {
        int type;
        String out, shiftOut, label, shiftLabel, hint, hintLabel;
        String[] extras;
        float weight = 1f;
        boolean dark, numSpace;
        final RectF rect = new RectF();
        final RectF hit = new RectF();
    }

    private static final class Ptr {
        Key key;
        int chip = -1;
        boolean popup, longFired, clipMode, moved;
        int sel = -1;
        float downY, lastY;
        List<String[]> items;
        final RectF popupRect = new RectF();
        Runnable longPress, repeat;
    }

    private Listener listener;
    private BijoyEngine labelEngine;
    private Typeface bijoyFont;

    private final List<Key[]> mainRows = new ArrayList<Key[]>();
    private final List<Key[]> sym1Rows = new ArrayList<Key[]>();
    private final List<Key[]> sym2Rows = new ArrayList<Key[]>();
    private final List<Key[]> numRows = new ArrayList<Key[]>();

    private int layoutIdx = L_UNI;
    private int page = P_MAIN;
    private int shiftState = SHIFT_OFF;
    private long lastShiftTap = 0;
    private String preview = "";
    private List<String> clips = new ArrayList<String>();
    private float clipScroll = 0;

    private final Paint fill = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint text = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint stroke = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final RectF tmp = new RectF();
    private final Rect bounds = new Rect();
    private final RectF[] btn = {new RectF(), new RectF(), new RectF()};
    private final RectF previewRect = new RectF();
    private final RectF clipClearRect = new RectF();
    private final Handler handler = new Handler(Looper.getMainLooper());
    private final SparseArray<Ptr> ptrs = new SparseArray<Ptr>();
    private final float density;
    private final float scaledDensity;

    public BijoyKeyboardView(Context c) {
        super(c);
        density = c.getResources().getDisplayMetrics().density;
        scaledDensity = c.getResources().getDisplayMetrics().scaledDensity;
        text.setTypeface(Typeface.DEFAULT);
        stroke.setStyle(Paint.Style.STROKE);
        stroke.setStrokeCap(Paint.Cap.ROUND);
        stroke.setStrokeJoin(Paint.Join.ROUND);
        try {
            bijoyFont = Typeface.createFromAsset(c.getAssets(), "fonts/SutonnyMJ.ttf");
        } catch (Exception e) {
            bijoyFont = null;
        }
        buildPages();
    }

    public void setListener(Listener l) { listener = l; }

    /** Engine used only to turn key faces into Bijoy ASCII so they can be drawn with SutonnyMJ. */
    public void setLabelEngine(BijoyEngine e) {
        labelEngine = e;
        invalidate();
    }

    public void setLayoutIndex(int i) {
        layoutIdx = i;
        shiftState = SHIFT_OFF;
        buildPages();
        layoutKeys();
        invalidate();
    }

    public void setPreview(String p) {
        preview = p == null ? "" : p;
        invalidate();
    }

    public void setClips(List<String> list) {
        clips = list == null ? new ArrayList<String>() : new ArrayList<String>(list);
        invalidate();
    }

    public void resetState() {
        cancelAll();
        shiftState = SHIFT_OFF;
        page = P_MAIN;
        layoutKeys();
        invalidate();
    }

    // ------------------------------------------------------------------ key tables

    private boolean isEng() { return layoutIdx == L_ENG; }

    private boolean isAscii() { return layoutIdx == L_2003 || layoutIdx == L_CLASSIC; }

    private static Key tk(String out, String shiftOut, String shiftLabel) {
        Key k = new Key();
        k.type = T_TEXT;
        k.out = out;
        k.shiftOut = shiftOut;
        k.shiftLabel = shiftLabel;
        return k;
    }

    private static Key skey(int type, float w, String label) {
        Key k = new Key();
        k.type = type;
        k.weight = w;
        k.label = label;
        return k;
    }

    private static Key[] row(String[] n, String[] s) {
        Key[] r = new Key[n.length];
        for (int i = 0; i < n.length; i++) r[i] = tk(n[i], s == null ? null : s[i], null);
        return r;
    }

    private static Key[] symRow(String chars) {
        Key[] r = new Key[chars.length()];
        for (int i = 0; i < r.length; i++) r[i] = tk(chars.substring(i, i + 1), null, null);
        return r;
    }

    private static Key[] withEnds(Key left, Key[] mid, Key right) {
        Key[] r = new Key[mid.length + 2];
        r[0] = left;
        System.arraycopy(mid, 0, r, 1, mid.length);
        r[r.length - 1] = right;
        return r;
    }

    private Key[] bottomRow(boolean main) {
        Key comma = tk(",", null, null);
        comma.extras = new String[] {".", "?", "!", ":", ";", "'"};
        Key last;
        if (isEng() || !main) {
            last = tk(".", null, null);
            last.extras = new String[] {"?", "!", ":", ";", "\"", "'"};
        } else {
            last = tk("\u0964", null, null);
            last.extras = new String[] {".", "?", "!"};
        }
        Key space = skey(T_SPACE, 3.9f, null);
        space.out = " ";
        Key left;
        if (main) left = skey(T_SYM, 1.5f, "?123");
        else left = skey(T_ABC, 1.5f, isEng() ? "ABC" : "\u09AC\u09BE\u0982\u09B2\u09BE");
        return new Key[] {left, skey(T_GLOBE, 1.1f, null), comma, space, last,
                skey(T_ENTER, 1.5f, null)};
    }

    private Key[] digitsRow() {
        String[] digits = isEng()
                ? new String[] {"1", "2", "3", "4", "5", "6", "7", "8", "9", "0"}
                : new String[] {"\u09E7", "\u09E8", "\u09E9", "\u09EA", "\u09EB", "\u09EC",
                        "\u09ED", "\u09EE", "\u09EF", "\u09E6"};
        Key[] r = row(digits, null);
        String[] sym = {"!", "@", "#", "$", "%", "^", "&", "*", "(", ")"};
        for (int i = 0; i < r.length; i++) {
            if (isEng()) {
                r[i].hint = sym[i];
            } else {
                r[i].shiftOut = sym[i];
            }
        }
        if (!isEng()) {
            if (layoutIdx == L_UNI) r[3].shiftOut = "\u09F3";
            r[3].shiftLabel = "\u09F3";
        }
        return r;
    }

    private void buildPages() {
        mainRows.clear();
        sym1Rows.clear();
        sym2Rows.clear();
        numRows.clear();

        mainRows.add(digitsRow());
        if (isEng()) {
            Key[] r1 = row(new String[] {"q", "w", "e", "r", "t", "y", "u", "i", "o", "p"},
                    new String[] {"Q", "W", "E", "R", "T", "Y", "U", "I", "O", "P"});
            String[] h1 = {"%", "\\", "|", "=", "[", "]", "<", ">", "{", "}"};
            for (int i = 0; i < r1.length; i++) r1[i].hint = h1[i];
            Key[] r2m = row(new String[] {"a", "s", "d", "f", "g", "h", "j", "k", "l"},
                    new String[] {"A", "S", "D", "F", "G", "H", "J", "K", "L"});
            String[] h2 = {"@", "#", "\u09F3", "_", "&", "-", "+", "(", ")"};
            for (int i = 0; i < r2m.length; i++) r2m[i].hint = h2[i];
            Key[] r3m = row(new String[] {"z", "x", "c", "v", "b", "n", "m"},
                    new String[] {"Z", "X", "C", "V", "B", "N", "M"});
            String[] h3 = {"*", "\"", "'", ":", ";", "!", "?"};
            for (int i = 0; i < r3m.length; i++) r3m[i].hint = h3[i];
            setExtras(r1, "e", "\u00E8\u00E9\u00EA\u00EB\u0113");
            setExtras(r1, "u", "\u00F9\u00FA\u00FB\u00FC\u016B");
            setExtras(r1, "i", "\u00EC\u00ED\u00EE\u00EF\u012B");
            setExtras(r1, "o", "\u00F2\u00F3\u00F4\u00F6\u0153\u00F5");
            setExtras(r1, "t", "\u00FE");
            setExtras(r1, "y", "\u00FD\u00FF");
            setExtras(r2m, "a", "\u00E0\u00E1\u00E2\u00E4\u00E6\u00E3");
            setExtras(r2m, "s", "\u00DF\u015B\u0161");
            setExtras(r2m, "d", "\u00F0");
            setExtras(r2m, "l", "\u0142");
            setExtras(r3m, "z", "\u017E\u017A\u017C");
            setExtras(r3m, "c", "\u00E7\u0107\u010D");
            setExtras(r3m, "n", "\u00F1\u0144");
            Key[] r2 = new Key[r2m.length + 2];
            r2[0] = skey(T_PAD, 0.5f, null);
            System.arraycopy(r2m, 0, r2, 1, r2m.length);
            r2[r2.length - 1] = skey(T_PAD, 0.5f, null);
            mainRows.add(r1);
            mainRows.add(r2);
            mainRows.add(withEnds(skey(T_SHIFT, 1.5f, null), r3m, skey(T_BACK, 1.5f, null)));
        } else {
            mainRows.add(row(new String[] {"\u0999", "\u09AF", "\u09A1", "\u09AA", "\u099F",
                            "\u099A", "\u099C", "\u09B9", "\u0997", "\u09DC"},
                    new String[] {"\u0982", "\u09DF", "\u09A2", "\u09AB", "\u09A0", "\u099B",
                            "\u099D", "\u099E", "\u0998", "\u09DD"}));
            mainRows.add(row(new String[] {"\u09C3", "\u09C1", "\u09BF", "\u09BE", "\u09CD",
                            "\u09AC", "\u0995", "\u09A4", "\u09A6", "\u09CE"},
                    new String[] {"\u0981", "\u09C2", "\u09C0", "\u0985", "\u0964", "\u09AD",
                            "\u0996", "\u09A5", "\u09A7", "\u0983"}));
            Key[] r3m = row(new String[] {"\u09CD\u09B0", "\u0993", "\u09C7", "\u09B0", "\u09A8",
                            "\u09B8", "\u09AE"},
                    new String[] {"\u09CD\u09AF", "\u09D7", "\u09C8", "\u09B2", "\u09A3",
                            "\u09B7", "\u09B6"});
            mainRows.add(withEnds(skey(T_SHIFT, 1.5f, null), r3m, skey(T_BACK, 1.5f, null)));
        }
        mainRows.add(bottomRow(true));

        // symbols page 1
        sym1Rows.add(digitsRow2());
        Key[] s1 = symRow("@#$%&-+()/");
        if (isAscii()) s1[2].label = "\u09F3";
        sym1Rows.add(s1);
        sym1Rows.add(symRow("*\"':;!?_=^"));
        Key[] mid = new Key[] {tk("\u2018", null, null), tk("\u2019", null, null),
                tk("\u201C", null, null), tk("\u201D", null, null), tk("~", null, null),
                tk("`", null, null), tk("\\", null, null)};
        sym1Rows.add(withEnds(skey(T_SYM2, 1.5f, "=\\<"), mid, skey(T_BACK, 1.5f, null)));
        sym1Rows.add(bottomRow(false));

        // symbols page 2
        sym2Rows.add(digitsRow2());
        sym2Rows.add(symRow("[]{}<>|\\^~"));
        boolean ext = layoutIdx == L_UNI || isEng();
        sym2Rows.add(symRow(ext ? "\u2022\u221A\u03C0\u00F7\u00D7\u00B6\u2206\u00A3\u20AC\u00A5"
                : "`,./?!:;'\""));
        Key[] mid2 = symRow(ext ? "\u00A9\u00AE\u2122\u00B0\u00A2\u00A4\u00A7" : "_-=+*%#");
        sym2Rows.add(withEnds(skey(T_SYM1, 1.5f, "?123"), mid2, skey(T_BACK, 1.5f, null)));
        sym2Rows.add(bottomRow(false));

        // number pad
        String[] nd = isEng()
                ? new String[] {"1", "2", "3", "4", "5", "6", "7", "8", "9", "0"}
                : new String[] {"\u09E7", "\u09E8", "\u09E9", "\u09EA", "\u09EB", "\u09EC",
                        "\u09ED", "\u09EE", "\u09EF", "\u09E6"};
        Key colon = tk(":", null, null);
        colon.dark = true;
        Key pct = tk("%", null, null);
        pct.dark = true;
        Key dot = tk(".", null, null);
        dot.dark = true;
        Key back = skey(T_BACK, 1f, null);
        Key sp = skey(T_SPACE, 1f, null);
        sp.out = " ";
        sp.numSpace = true;
        numRows.add(new Key[] {tk(nd[0], null, null), tk(nd[1], null, null), tk(nd[2], null, null), colon});
        numRows.add(new Key[] {tk(nd[3], null, null), tk(nd[4], null, null), tk(nd[5], null, null), pct});
        numRows.add(new Key[] {tk(nd[6], null, null), tk(nd[7], null, null), tk(nd[8], null, null), back});
        numRows.add(new Key[] {dot, tk(nd[9], null, null), sp, skey(T_ENTER, 1f, null)});
    }

    private Key[] digitsRow2() {
        Key[] r = digitsRow();
        for (Key k : r) { k.shiftOut = null; k.shiftLabel = null; k.hint = null; }
        return r;
    }

    private static void setExtras(Key[] row, String letter, String chars) {
        for (Key k : row) {
            if (k.type == T_TEXT && letter.equals(k.out)) {
                String[] e = new String[chars.length()];
                for (int i = 0; i < e.length; i++) e[i] = chars.substring(i, i + 1);
                k.extras = e;
            }
        }
    }

    private List<Key[]> rows() {
        switch (page) {
            case P_SYM1: return sym1Rows;
            case P_SYM2: return sym2Rows;
            case P_NUM: return numRows;
            default: return mainRows;
        }
    }

    // ------------------------------------------------------------------ geometry

    private float dp(float v) { return v * density; }

    private float spx(float v) { return v * scaledDensity; }

    private float toolbarH() { return dp(42); }

    private float keyH() {
        boolean land = getResources().getDisplayMetrics().widthPixels
                > getResources().getDisplayMetrics().heightPixels;
        return dp(land ? 40 : 50);
    }

    private float gap() { return dp(5); }

    private float areaH() { return 5 * keyH() + 4 * gap(); }

    @Override
    protected void onMeasure(int wSpec, int hSpec) {
        int w = MeasureSpec.getSize(wSpec);
        int h = (int) (toolbarH() + areaH() + 2 * gap());
        setMeasuredDimension(w, h);
    }

    @Override
    protected void onSizeChanged(int w, int h, int ow, int oh) {
        super.onSizeChanged(w, h, ow, oh);
        layoutKeys();
    }

    private void layoutKeys() {
        float w = getWidth();
        if (w <= 0) return;
        float padH = dp(4);
        float g = gap();
        List<Key[]> rs = rows();
        int n = rs.size();
        float rh = (areaH() - (n - 1) * g) / n;
        float y = toolbarH() + g;
        for (Key[] row : rs) {
            float total = 0;
            for (Key k : row) total += k.weight;
            float usable = w - 2 * padH - g * (row.length - 1);
            float x = padH;
            for (Key k : row) {
                float kw = usable * k.weight / total;
                k.rect.set(x, y, x + kw, y + rh);
                k.hit.set(x - g / 2, y - g / 2, x + kw + g / 2, y + rh + g / 2);
                x += kw + g;
            }
            y += rh + g;
        }
        // toolbar buttons
        float bh = toolbarH() - dp(10);
        float x0 = dp(8);
        btn[0].set(x0, dp(5), x0 + dp(46), dp(5) + bh);
        btn[1].set(x0 + dp(52), dp(5), x0 + dp(98), dp(5) + bh);
        text.setTypeface(Typeface.DEFAULT);
        text.setTextSize(spx(13));
        String pk = "\u0985\u09A8\u09CD\u09AF \u0995\u09BF\u09AC\u09CB\u09B0\u09CD\u09A1";
        float pw = text.measureText(pk) + dp(22);
        btn[2].set(w - dp(8) - pw, dp(5), w - dp(8), dp(5) + bh);
        previewRect.set(btn[1].right + dp(8), dp(5), btn[2].left - dp(8), dp(5) + bh);
        // clipboard header
        clipClearRect.set(w - dp(8) - dp(96), toolbarH() + g, w - dp(8), toolbarH() + g + dp(34));
    }

    // ------------------------------------------------------------------ drawing

    private static boolean isCombining(char c) {
        return (c >= '\u09BC' && c <= '\u09CD') || c == '\u09D7' || c == '\u0981';
    }

    private static String face(String s) {
        if (s == null || s.length() == 0) return "";
        if (isCombining(s.charAt(0))) return "\u25CC" + s;
        return s;
    }

    private static boolean isBanglaStr(String s) {
        if (s == null || s.length() == 0) return false;
        char c = s.charAt(0);
        return (c >= '\u0980' && c <= '\u09FF') || c == '\u0964' || c == '\u0965';
    }

    private boolean bijoyFaces() {
        return layoutIdx != L_ENG && bijoyFont != null && labelEngine != null;
    }

    /** item = {label, out, "1" if label must be drawn with the Bijoy font}. */
    private String[] item(String out, String labelOverride) {
        if (labelOverride != null) return new String[] {labelOverride, out, "0"};
        if (bijoyFaces() && isBanglaStr(out)) return new String[] {labelEngine.convert(out), out, "1"};
        return new String[] {face(out), out, "0"};
    }

    /** Draw a label centred at (cx, cy); Bijoy-font labels are centred on their glyph bounds. */
    private void drawLabel(Canvas canvas, String[] it, float cx, float cy, float sizeSp, int color) {
        text.setColor(color);
        if ("1".equals(it[2])) {
            text.setTypeface(bijoyFont);
            text.setTextSize(spx(sizeSp * 1.35f));
            text.setTextAlign(Paint.Align.LEFT);
            text.getTextBounds(it[0], 0, it[0].length(), bounds);
            float x = cx - (bounds.left + bounds.right) / 2f;
            float y = cy - (bounds.top + bounds.bottom) / 2f;
            canvas.drawText(it[0], x, y, text);
        } else {
            text.setTypeface(Typeface.DEFAULT);
            text.setTextSize(spx(sizeSp));
            text.setTextAlign(Paint.Align.CENTER);
            Paint.FontMetrics fm = text.getFontMetrics();
            canvas.drawText(it[0], cx, cy - (fm.ascent + fm.descent) / 2f, text);
        }
        text.setTypeface(Typeface.DEFAULT);
        text.setTextAlign(Paint.Align.CENTER);
    }

    private void drawHint(Canvas canvas, String[] it, RectF r) {
        text.setColor(COL_HINT);
        if ("1".equals(it[2])) {
            text.setTypeface(bijoyFont);
            text.setTextSize(spx(11 * 1.35f));
            text.setTextAlign(Paint.Align.LEFT);
            text.getTextBounds(it[0], 0, it[0].length(), bounds);
            canvas.drawText(it[0], r.right - dp(5) - bounds.right, r.top + dp(5) - bounds.top, text);
        } else {
            text.setTypeface(Typeface.DEFAULT);
            text.setTextSize(spx(11));
            text.setTextAlign(Paint.Align.RIGHT);
            Paint.FontMetrics fm = text.getFontMetrics();
            canvas.drawText(it[0], r.right - dp(5), r.top + dp(3) - fm.ascent, text);
        }
        text.setTypeface(Typeface.DEFAULT);
        text.setTextAlign(Paint.Align.CENTER);
    }

    private void drawPlain(Canvas canvas, String s, float cx, float cy, float sizeSp, int color) {
        drawLabel(canvas, new String[] {s, s, "0"}, cx, cy, sizeSp, color);
    }

    @Override
    protected void onDraw(Canvas canvas) {
        canvas.drawColor(COL_BG);
        drawToolbar(canvas);
        if (page == P_CLIP) {
            drawClipboard(canvas);
            return;
        }
        for (Key[] row : rows()) {
            for (Key k : row) drawKey(canvas, k);
        }
        for (int i = 0; i < ptrs.size(); i++) {
            Ptr p = ptrs.valueAt(i);
            if (p.popup) drawPopup(canvas, p);
        }
    }

    private void drawToolbar(Canvas canvas) {
        // clipboard button
        fill.setColor(page == P_CLIP ? COL_ACCENT : COL_KEY_DARK);
        canvas.drawRoundRect(btn[0], dp(14), dp(14), fill);
        stroke.setColor(COL_TEXT);
        stroke.setStrokeWidth(dp(1.8f));
        float cx = btn[0].centerX(), cy = btn[0].centerY();
        tmp.set(cx - dp(7), cy - dp(7), cx + dp(7), cy + dp(9));
        canvas.drawRoundRect(tmp, dp(2), dp(2), stroke);
        tmp.set(cx - dp(3.5f), cy - dp(10), cx + dp(3.5f), cy - dp(5));
        canvas.drawRoundRect(tmp, dp(1.5f), dp(1.5f), stroke);
        canvas.drawLine(cx - dp(3.5f), cy, cx + dp(3.5f), cy, stroke);
        canvas.drawLine(cx - dp(3.5f), cy + dp(4), cx + dp(3.5f), cy + dp(4), stroke);
        // number pad button
        fill.setColor(page == P_NUM ? COL_ACCENT : COL_KEY_DARK);
        canvas.drawRoundRect(btn[1], dp(14), dp(14), fill);
        drawPlain(canvas, "\u09E7\u09E8\u09E9", btn[1].centerX(), btn[1].centerY(), 14, COL_TEXT);
        // other keyboard
        fill.setColor(COL_KEY_DARK);
        canvas.drawRoundRect(btn[2], dp(14), dp(14), fill);
        drawPlain(canvas, "\u0985\u09A8\u09CD\u09AF \u0995\u09BF\u09AC\u09CB\u09B0\u09CD\u09A1",
                btn[2].centerX(), btn[2].centerY(), 13, COL_TEXT);
        // live preview of what is being typed (always real Unicode)
        if (previewRect.width() > dp(30) && preview.length() > 0) {
            fill.setColor(0xFF262626);
            canvas.drawRoundRect(previewRect, dp(14), dp(14), fill);
            text.setTypeface(Typeface.DEFAULT);
            text.setTextSize(spx(18));
            text.setColor(COL_TEXT);
            text.setTextAlign(Paint.Align.CENTER);
            String s = face(preview);
            float maxW = previewRect.width() - dp(20);
            int n = text.breakText(s, false, maxW - dp(14), null);
            if (n < s.length()) s = "\u2026" + s.substring(s.length() - n);
            Paint.FontMetrics fm = text.getFontMetrics();
            canvas.drawText(s, previewRect.centerX(), previewRect.centerY() - (fm.ascent + fm.descent) / 2f, text);
        }
    }

    private boolean isPressedKey(Key k) {
        for (int i = 0; i < ptrs.size(); i++) {
            if (ptrs.valueAt(i).key == k) return true;
        }
        return false;
    }

    private void drawKey(Canvas canvas, Key k) {
        if (k.type == T_PAD) return;
        boolean special = (k.type != T_TEXT && k.type != T_SPACE) || k.dark;
        int col = special ? COL_KEY_DARK : COL_KEY;
        if (k.type == T_ENTER) col = COL_ACCENT;
        if (k.type == T_SHIFT && shiftState != SHIFT_OFF) col = COL_KEY;
        if (isPressedKey(k)) col = COL_KEY_PRESSED;
        fill.setColor(col);
        canvas.drawRoundRect(k.rect, dp(6), dp(6), fill);
        float cx = k.rect.centerX();
        float cy = k.rect.centerY();
        float s = Math.min(k.rect.width(), k.rect.height());
        stroke.setColor(COL_TEXT);
        stroke.setStrokeWidth(dp(2));
        stroke.setStyle(Paint.Style.STROKE);
        switch (k.type) {
            case T_TEXT: {
                boolean sh = shiftState != SHIFT_OFF && page == P_MAIN && k.shiftOut != null;
                String[] main = sh ? item(k.shiftOut, k.shiftLabel) : item(k.out, k.label);
                drawLabel(canvas, main, cx, cy, page == P_NUM ? 28 : 22, COL_TEXT);
                if (page == P_MAIN) {
                    if (k.hint != null) {
                        drawHint(canvas, item(k.hint, k.hintLabel), k.rect);
                    } else if (k.shiftOut != null && !sh) {
                        drawHint(canvas, item(k.shiftOut, k.shiftLabel), k.rect);
                    }
                }
                break;
            }
            case T_SPACE: {
                if (k.numSpace) {
                    float a = dp(11);
                    Path p = new Path();
                    p.moveTo(cx - a, cy + dp(2));
                    p.lineTo(cx - a, cy + dp(8));
                    p.lineTo(cx + a, cy + dp(8));
                    p.lineTo(cx + a, cy + dp(2));
                    canvas.drawPath(p, stroke);
                } else {
                    String[] names = {"\u09AC\u09BF\u099C\u09AF\u09BC \u0987\u0989\u09A8\u09BF\u0995\u09CB\u09A1",
                            "\u09AC\u09BF\u099C\u09AF\u09BC \u09E8\u09E6\u09E6\u09E9",
                            "\u09AC\u09BF\u099C\u09AF\u09BC \u0995\u09CD\u09B2\u09BE\u09B8\u09BF\u0995",
                            "English"};
                    drawPlain(canvas, names[layoutIdx], cx, cy, 14, COL_HINT);
                }
                break;
            }
            case T_SYM:
            case T_ABC:
            case T_SYM1:
            case T_SYM2:
                drawPlain(canvas, k.label, cx, cy, 15, COL_TEXT);
                break;
            case T_SHIFT: {
                Path p = new Path();
                float a = s * 0.30f;
                p.moveTo(cx, cy - a);
                p.lineTo(cx + a, cy);
                p.lineTo(cx + a * 0.45f, cy);
                p.lineTo(cx + a * 0.45f, cy + a * 0.9f);
                p.lineTo(cx - a * 0.45f, cy + a * 0.9f);
                p.lineTo(cx - a * 0.45f, cy);
                p.lineTo(cx - a, cy);
                p.close();
                if (shiftState != SHIFT_OFF) {
                    fill.setColor(COL_TEXT);
                    canvas.drawPath(p, fill);
                } else {
                    canvas.drawPath(p, stroke);
                }
                if (shiftState == SHIFT_LOCK) {
                    fill.setColor(COL_ACCENT);
                    canvas.drawRect(cx - a * 0.45f, cy + a * 1.05f, cx + a * 0.45f,
                            cy + a * 1.05f + dp(3), fill);
                }
                break;
            }
            case T_BACK: {
                float a = Math.min(k.rect.width(), k.rect.height() * 1.4f) * 0.22f;
                Path p = new Path();
                p.moveTo(cx - a * 1.3f, cy);
                p.lineTo(cx - a * 0.5f, cy - a * 0.8f);
                p.lineTo(cx + a * 1.3f, cy - a * 0.8f);
                p.lineTo(cx + a * 1.3f, cy + a * 0.8f);
                p.lineTo(cx - a * 0.5f, cy + a * 0.8f);
                p.close();
                canvas.drawPath(p, stroke);
                canvas.drawLine(cx - a * 0.2f, cy - a * 0.35f, cx + a * 0.7f, cy + a * 0.35f, stroke);
                canvas.drawLine(cx - a * 0.2f, cy + a * 0.35f, cx + a * 0.7f, cy - a * 0.35f, stroke);
                break;
            }
            case T_ENTER: {
                float a = Math.min(k.rect.width(), k.rect.height() * 1.4f) * 0.2f;
                canvas.drawLine(cx + a, cy - a, cx + a, cy, stroke);
                canvas.drawLine(cx + a, cy, cx - a, cy, stroke);
                canvas.drawLine(cx - a, cy, cx - a * 0.3f, cy - a * 0.7f, stroke);
                canvas.drawLine(cx - a, cy, cx - a * 0.3f, cy + a * 0.7f, stroke);
                break;
            }
            case T_GLOBE: {
                float r = s * 0.28f;
                canvas.drawCircle(cx, cy, r, stroke);
                canvas.drawLine(cx - r, cy, cx + r, cy, stroke);
                tmp.set(cx - r * 0.45f, cy - r, cx + r * 0.45f, cy + r);
                canvas.drawOval(tmp, stroke);
                break;
            }
            default:
                break;
        }
    }

    private void drawPopup(Canvas canvas, Ptr p) {
        fill.setColor(0xFF3B3B3B);
        tmp.set(p.popupRect);
        tmp.inset(-dp(3), -dp(3));
        canvas.drawRoundRect(tmp, dp(8), dp(8), fill);
        int n = p.items.size();
        float cw = p.popupRect.width() / n;
        for (int i = 0; i < n; i++) {
            if (i == p.sel) {
                fill.setColor(COL_ACCENT);
                tmp.set(p.popupRect.left + i * cw + dp(2), p.popupRect.top,
                        p.popupRect.left + (i + 1) * cw - dp(2), p.popupRect.bottom);
                canvas.drawRoundRect(tmp, dp(6), dp(6), fill);
            }
            drawLabel(canvas, p.items.get(i), p.popupRect.left + (i + 0.5f) * cw,
                    p.popupRect.centerY(), 22, COL_TEXT);
        }
    }

    // ------------------------------------------------------------------ clipboard page

    private float clipRowH() { return dp(46); }

    private float clipListTop() { return toolbarH() + gap() + dp(40); }

    private float clipListBottom() { return getHeight() - gap(); }

    private float clipMaxScroll() {
        float content = clips.size() * (clipRowH() + gap());
        return Math.max(0, content - (clipListBottom() - clipListTop()));
    }

    private void drawClipboard(Canvas canvas) {
        float w = getWidth();
        float top = toolbarH() + gap();
        drawPlain(canvas, "\u0995\u09CD\u09B2\u09BF\u09AA\u09AC\u09CB\u09B0\u09CD\u09A1",
                dp(60), top + dp(17), 16, COL_TEXT);
        fill.setColor(COL_KEY_DARK);
        canvas.drawRoundRect(clipClearRect, dp(14), dp(14), fill);
        drawPlain(canvas, "\u09B8\u09AC \u09AE\u09C1\u099B\u09C1\u09A8", clipClearRect.centerX(),
                clipClearRect.centerY(), 13, COL_TEXT);
        float listTop = clipListTop();
        float listBottom = clipListBottom();
        if (clips.isEmpty()) {
            drawPlain(canvas, "\u0995\u09CB\u09A8\u09CB \u0995\u09AA\u09BF \u0995\u09B0\u09BE \u09B2\u09C7\u0996\u09BE \u09A8\u09C7\u0987",
                    w / 2, (listTop + listBottom) / 2, 15, COL_HINT);
            return;
        }
        canvas.save();
        canvas.clipRect(0, listTop, w, listBottom);
        float rh = clipRowH();
        for (int i = 0; i < clips.size(); i++) {
            float y = listTop + i * (rh + gap()) - clipScroll;
            if (y + rh < listTop || y > listBottom) continue;
            tmp.set(dp(4), y, w - dp(4), y + rh);
            fill.setColor(COL_KEY);
            canvas.drawRoundRect(tmp, dp(6), dp(6), fill);
            String s = clips.get(i).replace('\n', ' ').replace('\r', ' ').replace('\t', ' ');
            text.setTypeface(Typeface.DEFAULT);
            text.setTextSize(spx(16));
            text.setColor(COL_TEXT);
            text.setTextAlign(Paint.Align.LEFT);
            float maxW = w - dp(8) - dp(52) - dp(12);
            int n = text.breakText(s, true, maxW, null);
            if (n < s.length()) s = s.substring(0, n) + "\u2026";
            Paint.FontMetrics fm = text.getFontMetrics();
            canvas.drawText(s, dp(14), tmp.centerY() - (fm.ascent + fm.descent) / 2f, text);
            text.setTextAlign(Paint.Align.CENTER);
            stroke.setColor(COL_HINT);
            stroke.setStrokeWidth(dp(1.8f));
            float xc = w - dp(4) - dp(26);
            float yc = tmp.centerY();
            canvas.drawLine(xc - dp(5), yc - dp(5), xc + dp(5), yc + dp(5), stroke);
            canvas.drawLine(xc - dp(5), yc + dp(5), xc + dp(5), yc - dp(5), stroke);
        }
        canvas.restore();
    }

    private void clipTap(float x, float y) {
        if (clipClearRect.contains(x, y)) {
            if (listener != null) listener.onClipClear();
            return;
        }
        float listTop = clipListTop();
        if (y < listTop || y > clipListBottom()) return;
        int i = (int) Math.floor((y - listTop + clipScroll) / (clipRowH() + gap()));
        if (i < 0 || i >= clips.size()) return;
        if (x > getWidth() - dp(60)) {
            if (listener != null) listener.onClipDelete(i);
        } else {
            String t = clips.get(i);
            page = P_MAIN;
            layoutKeys();
            if (listener != null) listener.onClipPaste(t);
        }
    }

    // ------------------------------------------------------------------ touch

    @Override
    public boolean onTouchEvent(MotionEvent ev) {
        int action = ev.getActionMasked();
        int idx = ev.getActionIndex();
        switch (action) {
            case MotionEvent.ACTION_DOWN:
            case MotionEvent.ACTION_POINTER_DOWN:
                down(ev.getPointerId(idx), ev.getX(idx), ev.getY(idx));
                break;
            case MotionEvent.ACTION_MOVE:
                for (int i = 0; i < ev.getPointerCount(); i++) {
                    move(ev.getPointerId(i), ev.getX(i), ev.getY(i));
                }
                break;
            case MotionEvent.ACTION_UP:
            case MotionEvent.ACTION_POINTER_UP:
                up(ev.getPointerId(idx), ev.getX(idx), ev.getY(idx));
                break;
            case MotionEvent.ACTION_CANCEL:
                cancelAll();
                invalidate();
                break;
            default:
                break;
        }
        return true;
    }

    private Key hitKey(float x, float y) {
        Key best = null;
        float bestD = Float.MAX_VALUE;
        for (Key[] row : rows()) {
            for (Key k : row) {
                if (k.type == T_PAD) continue;
                if (k.hit.contains(x, y)) return k;
                float dx = Math.max(Math.max(k.rect.left - x, 0), x - k.rect.right);
                float dy = Math.max(Math.max(k.rect.top - y, 0), y - k.rect.bottom);
                float d = dx * dx + dy * dy;
                if (d < bestD) { bestD = d; best = k; }
            }
        }
        return bestD < dp(14) * dp(14) ? best : null;
    }

    private int hitBtn(float x, float y) {
        for (int i = 0; i < 3; i++) {
            if (btn[i].contains(x, y)) return i;
        }
        return -1;
    }

    private boolean hasPopup(Key k) {
        return k.type == T_TEXT && (k.shiftOut != null || k.extras != null || k.hint != null);
    }

    private void down(final int id, float x, float y) {
        final Ptr p = new Ptr();
        ptrs.put(id, p);
        p.downY = y;
        p.lastY = y;
        if (y < toolbarH()) {
            p.chip = hitBtn(x, y);
            invalidate();
            return;
        }
        if (page == P_CLIP) {
            p.clipMode = true;
            return;
        }
        final Key k = hitKey(x, y);
        p.key = k;
        if (k == null) return;
        performHapticFeedback(HapticFeedbackConstants.KEYBOARD_TAP);
        if (k.type == T_BACK) {
            if (listener != null) listener.onBackspace();
            p.repeat = new Runnable() {
                @Override public void run() {
                    if (listener != null) listener.onBackspace();
                    handler.postDelayed(this, 45);
                }
            };
            handler.postDelayed(p.repeat, 400);
        } else if (hasPopup(k) || k.type == T_GLOBE) {
            p.longPress = new Runnable() {
                @Override public void run() { longPressed(p, k); }
            };
            handler.postDelayed(p.longPress, k.type == T_GLOBE ? 500 : 350);
        }
        invalidate();
    }

    private void longPressed(Ptr p, Key k) {
        if (k.type == T_GLOBE) {
            p.longFired = true;
            if (listener != null) listener.onGlobeLong();
            invalidate();
            return;
        }
        List<String[]> items = new ArrayList<String[]>();
        boolean shifted = shiftState != SHIFT_OFF && page == P_MAIN;
        if (k.hint != null) {
            items.add(item(k.hint, k.hintLabel));
        } else if (k.shiftOut != null) {
            if (shifted) items.add(item(k.out, k.label));
            else items.add(item(k.shiftOut, k.shiftLabel));
        }
        if (k.extras != null) {
            for (String e : k.extras) {
                items.add(item(shifted && isEng() ? e.toUpperCase() : e, null));
            }
        }
        if (items.isEmpty()) return;
        p.items = items;
        p.popup = true;
        p.sel = 0;
        float cw = Math.max(dp(46), k.rect.width());
        float maxTotal = getWidth() - dp(8);
        if (cw * items.size() > maxTotal) cw = maxTotal / items.size();
        float total = cw * items.size();
        float left = k.rect.centerX() - total / 2;
        left = Math.max(dp(4), Math.min(left, getWidth() - dp(4) - total));
        float ph = Math.max(dp(40), k.rect.height());
        float top = Math.max(dp(2), k.rect.top - ph - dp(10));
        p.popupRect.set(left, top, left + total, top + ph);
        performHapticFeedback(HapticFeedbackConstants.LONG_PRESS);
        invalidate();
    }

    private void move(int id, float x, float y) {
        Ptr p = ptrs.get(id);
        if (p == null) return;
        if (p.clipMode) {
            if (Math.abs(y - p.downY) > dp(8)) p.moved = true;
            if (p.moved) {
                clipScroll = Math.max(0, Math.min(clipMaxScroll(), clipScroll + (p.lastY - y)));
                invalidate();
            }
            p.lastY = y;
            return;
        }
        if (p.popup) {
            float cw = p.popupRect.width() / p.items.size();
            int i = (int) Math.floor((x - p.popupRect.left) / cw);
            i = Math.max(0, Math.min(p.items.size() - 1, i));
            if (i != p.sel) {
                p.sel = i;
                invalidate();
            }
        } else if (p.key != null && !p.key.hit.contains(x, y)) {
            if (p.longPress != null) handler.removeCallbacks(p.longPress);
        }
    }

    private void up(int id, float x, float y) {
        Ptr p = ptrs.get(id);
        ptrs.remove(id);
        if (p == null) return;
        if (p.longPress != null) handler.removeCallbacks(p.longPress);
        if (p.repeat != null) handler.removeCallbacks(p.repeat);
        if (p.chip >= 0) {
            if (hitBtn(x, y) == p.chip) toolbarTap(p.chip);
            invalidate();
            return;
        }
        if (p.clipMode) {
            if (!p.moved) clipTap(x, y);
            invalidate();
            return;
        }
        Key k = p.key;
        if (k != null) {
            if (p.popup) {
                if (p.sel >= 0) emitText(p.items.get(p.sel)[1]);
            } else if (!p.longFired && k.type != T_BACK && k.hit.contains(x, y)) {
                tap(k);
            }
        }
        invalidate();
    }

    private void toolbarTap(int which) {
        if (which == 0) {
            page = page == P_CLIP ? P_MAIN : P_CLIP;
            clipScroll = 0;
            layoutKeys();
        } else if (which == 1) {
            page = page == P_NUM ? P_MAIN : P_NUM;
            layoutKeys();
        } else if (listener != null) {
            listener.onPickerRequest();
        }
    }

    private void cancelAll() {
        for (int i = 0; i < ptrs.size(); i++) {
            Ptr p = ptrs.valueAt(i);
            if (p.longPress != null) handler.removeCallbacks(p.longPress);
            if (p.repeat != null) handler.removeCallbacks(p.repeat);
        }
        ptrs.clear();
    }

    private void emitText(String out) {
        if (listener != null) listener.onText(out);
        if (shiftState == SHIFT_ON) shiftState = SHIFT_OFF;
    }

    private void tap(Key k) {
        switch (k.type) {
            case T_TEXT: {
                boolean sh = shiftState != SHIFT_OFF && page == P_MAIN && k.shiftOut != null;
                emitText(sh ? k.shiftOut : k.out);
                break;
            }
            case T_SPACE:
                if (listener != null) listener.onText(" ");
                if (shiftState == SHIFT_ON) shiftState = SHIFT_OFF;
                break;
            case T_SHIFT: {
                long now = System.currentTimeMillis();
                if (shiftState == SHIFT_OFF) {
                    shiftState = SHIFT_ON;
                } else if (shiftState == SHIFT_ON && now - lastShiftTap < 400) {
                    shiftState = SHIFT_LOCK;
                } else {
                    shiftState = SHIFT_OFF;
                }
                lastShiftTap = now;
                break;
            }
            case T_ENTER:
                if (listener != null) listener.onEnter();
                break;
            case T_GLOBE:
                if (listener != null) listener.onGlobeTap();
                break;
            case T_SYM:
            case T_SYM1:
                page = P_SYM1;
                layoutKeys();
                break;
            case T_SYM2:
                page = P_SYM2;
                layoutKeys();
                break;
            case T_ABC:
                page = P_MAIN;
                layoutKeys();
                break;
            default:
                break;
        }
    }
}
