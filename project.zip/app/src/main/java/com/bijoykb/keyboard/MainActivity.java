package com.bijoykb.keyboard;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Typeface;
import android.os.Bundle;
import android.provider.Settings;
import android.view.View;
import android.view.inputmethod.InputMethodManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

public class MainActivity extends Activity {

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        float d = getResources().getDisplayMetrics().density;
        int pad = (int) (20 * d);

        ScrollView sv = new ScrollView(this);
        LinearLayout ll = new LinearLayout(this);
        ll.setOrientation(LinearLayout.VERTICAL);
        ll.setPadding(pad, pad, pad, pad);
        sv.addView(ll);

        TextView title = new TextView(this);
        title.setText("\u09AC\u09BF\u099C\u09AF\u09BC ASCII \u0995\u09BF\u09AC\u09CB\u09B0\u09CD\u09A1");
        title.setTextSize(24);
        ll.addView(title);

        TextView info = new TextView(this);
        info.setText("\u098F\u0987 \u0995\u09BF\u09AC\u09CB\u09B0\u09CD\u09A1\u09C7\u09B0 ASCII \u09B2\u09C7\u0996\u09BE \u09B8\u09A0\u09BF\u0995 \u09A6\u09C7\u0996\u09A4\u09C7 \u099A\u09BE\u0987\u09B2\u09C7 \u09AF\u09C7 \u09B8\u09CD\u09A5\u09BE\u09A8\u09C7 \u09B2\u09BF\u0996\u09AC\u09C7\u09A8 \u09B8\u09C7\u0996\u09BE\u09A8\u09C7 "
                + "\u09AC\u09BF\u099C\u09AF\u09BC \u0989\u09AD\u09AF\u09BC \u09B8\u0982\u09B8\u09CD\u0995\u09B0\u09A3\u09C7\u09B0 \u0995\u09CD\u09B7\u09C7\u09A4\u09CD\u09B0\u09C7 \u09AD\u09BF\u09A8\u09CD\u09A8 \u09AB\u09A8\u09CD\u099F \u09A5\u09BE\u0995\u09A4\u09C7 \u09B9\u09AC\u09C7\u0964\n\n"
                + "\u09E7. \u09AA\u09CD\u09B0\u09A5\u09AE\u09C7 \u0995\u09BF\u09AC\u09CB\u09B0\u09CD\u09A1 \u099A\u09BE\u09B2\u09C1 \u0995\u09B0\u09C1\u09A8\u0964\n\u09E8. \u09A4\u09BE\u09B0\u09AA\u09B0 \u0995\u09BF\u09AC\u09CB\u09B0\u09CD\u09A1 \u09A8\u09BF\u09B0\u09CD\u09AC\u09BE\u099A\u09A8 \u0995\u09B0\u09C1\u09A8\u0964\n\n"
                + "\u09A8\u09BF\u099A\u09C7\u09B0 \u0997\u09CD\u09B2\u09CB\u09AC \u0995\u09C0 \u099A\u09BE\u09AA\u09B2\u09C7 \u0995\u09BF-\u09AC\u09CB\u09B0\u09CD\u09A1\u09C7\u09B0 \u09B2\u09C7-\u0986\u0989\u099F \u09B8\u09AE\u09C2\u09B9 \u09AC\u09A6\u09B2\u09BE\u09AC\u09C7; "
                + "\u0997\u09CD\u09B2\u09CB\u09AC \u0995\u09C0 \u099A\u09C7\u09AA\u09C7 \u09A7\u09B0\u09B2\u09C7 \u0985\u09A8\u09CD\u09AF \u0995\u09BF\u09AC\u09CB\u09B0\u09CD\u09A1\u09C7 \u09AF\u09BE\u0993\u09AF\u09BC\u09BE \u09AF\u09BE\u09AC\u09C7\u0964");
        info.setTextSize(16);
        info.setPadding(0, pad / 2, 0, pad / 2);
        ll.addView(info);

        Button enable = new Button(this);
        enable.setText("\u09E7. \u0995\u09BF\u09AC\u09CB\u09B0\u09CD\u09A1 \u099A\u09BE\u09B2\u09C1 \u0995\u09B0\u09C1\u09A8");
        enable.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) {
                startActivity(new Intent(Settings.ACTION_INPUT_METHOD_SETTINGS));
            }
        });
        ll.addView(enable);

        Button pick = new Button(this);
        pick.setText("\u09E8. \u0995\u09BF\u09AC\u09CB\u09B0\u09CD\u09A1 \u09A8\u09BF\u09B0\u09CD\u09AC\u09BE\u099A\u09A8 \u0995\u09B0\u09C1\u09A8");
        pick.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) {
                InputMethodManager imm = (InputMethodManager) getSystemService(INPUT_METHOD_SERVICE);
                if (imm != null) imm.showInputMethodPicker();
            }
        });
        ll.addView(pick);

        TextView hint = new TextView(this);
        hint.setText("\n\u09AA\u09B0\u09C0\u0995\u09CD\u09B7\u09BE\u09B0 \u0998\u09B0:");
        hint.setTextSize(14);
        ll.addView(hint);

        EditText test = new EditText(this);
        test.setMinLines(4);
        test.setTextSize(22);
        try {
            test.setTypeface(Typeface.createFromAsset(getAssets(), "fonts/SutonnyMJ.ttf"));
        } catch (Exception e) {
            // font not bundled; text shows as plain ASCII
        }
        ll.addView(test);

        setContentView(sv);
    }
}
