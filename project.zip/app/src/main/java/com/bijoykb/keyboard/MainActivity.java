package com.bijoykb.keyboard;

import android.app.Activity;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Typeface;
import android.os.Bundle;
import android.provider.Settings;
import android.view.View;
import android.view.inputmethod.InputMethodManager;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.SeekBar;
import android.widget.TextView;

public class MainActivity extends Activity {

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        float d = getResources().getDisplayMetrics().density;
        int pad = (int) (20 * d);

        ScrollView sv = new ScrollView(this);
        LinearLayout ll = new LinearLayout(this);
        ll.setOrientation(LinearLayout.VERTICAL);
        ll.setPadding(pad, pad, pad, pad);
        sv.addView(ll);

        TextView title = new TextView(this);
        title.setText("\u09AC\u09BF\u099C\u09AF\u09BC ASCII \u0995\u09BF\u09AC\u09CB\u09B0\u09CD\u09A1");
        title.setTextSize(24);
        ll.addView(title);

        TextView info = new TextView(this);
        info.setText("\u098F\u0987 \u0995\u09BF\u09AC\u09CB\u09B0\u09CD\u09A1\u09C7\u09B0 ASCII \u09B2\u09C7\u0996\u09BE \u09B8\u09A0\u09BF\u0995 \u09A6\u09C7\u0996\u09A4\u09C7 \u099A\u09BE\u0987\u09B2\u09C7 \u09AF\u09C7 \u09B8\u09CD\u09A5\u09BE\u09A8\u09C7 \u09B2\u09BF\u0996\u09AC\u09C7\u09A8 \u09B8\u09C7\u0996\u09BE\u09A8\u09C7 "
                + "\u09AC\u09BF\u099C\u09AF\u09BC \u0989\u09AD\u09AF\u09BC \u09B8\u0982\u09B8\u09CD\u0995\u09B0\u09A3\u09C7\u09B0 \u0995\u09CD\u09B7\u09C7\u09A4\u09CD\u09B0\u09C7 \u09AD\u09BF\u09A8\u09CD\u09A8 \u09AB\u09A8\u09CD\u099F \u09A5\u09BE\u0995\u09A4\u09C7 \u09B9\u09AC\u09C7\u0964\n\n"
                + "\u09E7. \u09AA\u09CD\u09B0\u09A5\u09AE\u09C7 \u0995\u09BF\u09AC\u09CB\u09B0\u09CD\u09A1 \u099A\u09BE\u09B2\u09C1 \u0995\u09B0\u09C1\u09A8\u0964\n\u09E8. \u09A4\u09BE\u09B0\u09AA\u09B0 \u0995\u09BF\u09AC\u09CB\u09B0\u09CD\u09A1 \u09A8\u09BF\u09B0\u09CD\u09AC\u09BE\u099A\u09A8 \u0995\u09B0\u09C1\u09A8\u0964\n\n"
                + "\u09A8\u09BF\u099A\u09C7\u09B0 \u0997\u09CD\u09B2\u09CB\u09AC \u0995\u09C0 \u099A\u09BE\u09AA\u09B2\u09C7 \u0995\u09BF-\u09AC\u09CB\u09B0\u09CD\u09A1\u09C7\u09B0 \u09B2\u09C7-\u0986\u0989\u099F \u09B8\u09AE\u09C2\u09B9 \u09AC\u09A6\u09B2\u09BE\u09AC\u09C7; "
                + "\u0997\u09CD\u09B2\u09CB\u09AC \u0995\u09C0 \u099A\u09C7\u09AA\u09C7 \u09A7\u09B0\u09B2\u09C7 \u0985\u09A8\u09CD\u09AF \u0995\u09BF\u09AC\u09CB\u09B0\u09CD\u09A1\u09C7 \u09AF\u09BE\u0993\u09AF\u09BC\u09BE \u09AF\u09BE\u09AC\u09C7\u0964");
        info.setTextSize(16);
        info.setPadding(0, pad / 2, 0, pad / 2);
        ll.addView(info);

        Button enable = new Button(this);
        enable.setText("\u09E7. \u0995\u09BF\u09AC\u09CB\u09B0\u09CD\u09A1 \u099A\u09BE\u09B2\u09C1 \u0995\u09B0\u09C1\u09A8");
        enable.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) {
                startActivity(new Intent(Settings.ACTION_INPUT_METHOD_SETTINGS));
            }
        });
        ll.addView(enable);

        Button pick = new Button(this);
        pick.setText("\u09E8. \u0995\u09BF\u09AC\u09CB\u09B0\u09CD\u09A1 \u09A8\u09BF\u09B0\u09CD\u09AC\u09BE\u099A\u09A8 \u0995\u09B0\u09C1\u09A8");
        pick.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) {
                InputMethodManager imm = (InputMethodManager) getSystemService(INPUT_METHOD_SERVICE);
                if (imm != null) imm.showInputMethodPicker();
            }
        });
        ll.addView(pick);

        SharedPreferences sp = getSharedPreferences("bijoy_prefs", MODE_PRIVATE);
        addCheck(ll, sp, "dt_bangla", true,
                "\u09AC\u09BE\u0982\u09B2\u09BE \u09B2\u09C7\u0986\u0989\u099F\u09C7 \u098F\u0995\u0987 \u09AC\u09B0\u09CD\u09A3\u09C7 \u09E7 \u09B8\u09C7\u0995\u09C7\u09A8\u09CD\u09A1\u09C7\u09B0 \u09AE\u09A7\u09CD\u09AF\u09C7 \u09A1\u09AC\u09B2 \u099F\u09CD\u09AF\u09BE\u09AA \u0995\u09B0\u09B2\u09C7 \u09A4\u09BE\u09B0 \u09B6\u09BF\u09AB\u099F \u09AC\u09B0\u09CD\u09A3 \u09AC\u09B8\u09AC\u09C7");
        addCheck(ll, sp, "dt_english", false,
                "English-\u098F\u0993 \u09A1\u09AC\u09B2 \u099F\u09CD\u09AF\u09BE\u09AA\u09C7 \u09AC\u09A1\u09BC \u09B9\u09BE\u09A4\u09C7\u09B0 \u0985\u0995\u09CD\u09B7\u09B0 \u09AC\u09B8\u09AC\u09C7 (hello-\u09B0 \u09AE\u09A4\u09CB \u09B6\u09AC\u09CD\u09A6 \u09B2\u09BF\u0996\u09A4\u09C7 \u0985\u09B8\u09C1\u09AC\u09BF\u09A7\u09BE \u09B9\u09AF\u09BC)");
        addCheck(ll, sp, "vol_cursor", true, "\u09AD\u09B2\u09BF\u0989\u09AE \u0986\u09AA/\u09A1\u09BE\u0989\u09A8\u09C7 \u0995\u09BE\u09B0\u09CD\u09B8\u09B0 \u09A1\u09BE\u09A8\u09C7/\u09AC\u09BE\u09AE\u09C7 \u09AF\u09BE\u09AC\u09C7");

        TextView sizeTitle = new TextView(this);
        sizeTitle.setText("\n\u0995\u09BF\u09AC\u09CB\u09B0\u09CD\u09A1\u09C7\u09B0 \u0986\u0995\u09BE\u09B0");
        sizeTitle.setTextSize(18);
        ll.addView(sizeTitle);
        addSeek(ll, sp, "Keyboard Height (Portrait)", "h_port", 60, 170, 100);
        addSeek(ll, sp, "Keyboard Height (Landscape)", "h_land", 60, 170, 125);
        addSeek(ll, sp, "One Handed Keyboard Width (Portrait)", "ow_port", 30, 100, 85);
        addSeek(ll, sp, "One Handed Keyboard Width (Landscape)", "ow_land", 30, 100, 40);
        TextView oneInfo = new TextView(this);
        oneInfo.setText("\u098F\u0995 \u09B9\u09BE\u09A4\u09C7 \u09B2\u09BF\u0996\u09A4\u09C7 \u0995\u09BF\u09AC\u09CB\u09B0\u09CD\u09A1\u09C7\u09B0 \u0989\u09AA\u09B0\u09C7\u09B0 \u09B8\u09BE\u09B0\u09BF\u09B0 \u09AC\u09BE\u09AE\u09C7\u09B0 \u099B\u09CB\u099F \u09AB\u09CB\u09A8 \u0986\u0987\u0995\u09A8\u099F\u09BF \u099A\u09BE\u09AA\u09C1\u09A8\u0964 \u09AA\u09B0\u09BF\u09AC\u09B0\u09CD\u09A4\u09A8 \u09AA\u09B0\u09C7\u09B0 \u09AC\u09BE\u09B0 \u0995\u09BF\u09AC\u09CB\u09B0\u09CD\u09A1 \u0996\u09C1\u09B2\u09B2\u09C7 \u0995\u09BE\u099C \u0995\u09B0\u09AC\u09C7\u0964");
        oneInfo.setTextSize(13);
        ll.addView(oneInfo);

        TextView hint = new TextView(this);
        hint.setText("\n\u09AA\u09B0\u09C0\u0995\u09CD\u09B7\u09BE\u09B0 \u0998\u09B0:");
        hint.setTextSize(14);
        ll.addView(hint);

        EditText test = new EditText(this);
        test.setMinLines(4);
        test.setTextSize(22);
        try {
            test.setTypeface(Typeface.createFromAsset(getAssets(), "fonts/SutonnyMJ.ttf"));
        } catch (Exception e) {
            // font not bundled; text shows as plain ASCII
        }
        ll.addView(test);

        setContentView(sv);
    }

    private void addSeek(LinearLayout ll, final SharedPreferences sp, final String label,
                         final String key, final int min, final int max, int def) {
        final TextView t = new TextView(this);
        t.setTextSize(15);
        t.setPadding(0, 16, 0, 0);
        int cur = sp.getInt(key, def);
        cur = Math.max(min, Math.min(max, cur));
        t.setText(label + ": " + cur + "%");
        SeekBar sb = new SeekBar(this);
        sb.setMax(max - min);
        sb.setProgress(cur - min);
        sb.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override public void onProgressChanged(SeekBar s, int p, boolean user) {
                t.setText(label + ": " + (p + min) + "%");
                if (user) sp.edit().putInt(key, p + min).apply();
            }
            @Override public void onStartTrackingTouch(SeekBar s) { }
            @Override public void onStopTrackingTouch(SeekBar s) { }
        });
        ll.addView(t);
        ll.addView(sb);
    }

    private void addCheck(LinearLayout ll, final SharedPreferences sp, final String key,
                          boolean def, String label) {
        CheckBox cb = new CheckBox(this);
        cb.setText(label);
        cb.setChecked(sp.getBoolean(key, def));
        cb.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override public void onCheckedChanged(CompoundButton b, boolean checked) {
                sp.edit().putBoolean(key, checked).apply();
            }
        });
        ll.addView(cb);
    }
}
