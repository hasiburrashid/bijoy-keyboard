package com.bijoykb.keyboard;

import java.io.BufferedReader;
import java.io.IOException;
import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.List;

/**
 * Pure-Java typing engine. Takes Bijoy key presses (logical Unicode letters for Bangla
 * keys, plain ASCII for literal keys) and produces edits on Bijoy ASCII text.
 *
 * The conjunct tables (conj-*.txt) are exactly the converter tables of the At-Tahreek
 * uni2bijoy converter, so typed conjuncts change into the same ASCII characters.
 */
public final class BijoyEngine {

    /** Delete [delete] chars before the cursor, then insert [insert]. */
    public static final class Edit {
        public final int delete;
        public final String insert;
        Edit(int delete, String insert) {
            this.delete = delete;
            this.insert = insert;
        }
    }

    private static final class Snap {
        String pre, cluster, post, ascii, word, left;
        String removed, inserted;
    }

    private static final char HAS = '\u09CD';
    private static final char RA = '\u09B0';
    private static final int MAX_HISTORY = 80;

    private final List<String[]> map;
    private final boolean unicodeMode;
    private final List<String[]> finish;
    private String left = "";
    private String word = "";
    private String pre = "", cluster = "", post = "", ascii = "";
    private final ArrayDeque<Snap> history = new ArrayDeque<Snap>();

    public BijoyEngine(List<String[]> conjunctMap) {
        this(conjunctMap, false);
    }

    /** unicodeMode: write real Unicode (Bijoy Unicode / English) instead of Bijoy ASCII. */
    public BijoyEngine(List<String[]> conjunctMap, boolean unicodeMode) {
        this(conjunctMap, new ArrayList<String[]>(), unicodeMode);
    }

    /** finishRules: the "finishing touch" replacements (word-initial e-kar, u-kar variants...). */
    public BijoyEngine(List<String[]> conjunctMap, List<String[]> finishRules, boolean unicodeMode) {
        this.map = conjunctMap;
        this.finish = finishRules;
        this.unicodeMode = unicodeMode;
    }

    /** The character just before the syllable being typed ("" at the start of the text). */
    public void setLeft(String l) {
        left = l == null ? "" : l;
    }

    /** Lines: "hex hex hex<TAB>hex hex" (code points). */
    public static List<String[]> parseMap(BufferedReader r) throws IOException {
        List<String[]> out = new ArrayList<String[]>();
        String line;
        while ((line = r.readLine()) != null) {
            if (line.length() == 0) continue;
            String[] parts = line.split("\t", -1);
            if (parts.length != 2) continue;
            out.add(new String[] {decode(parts[0]), decode(parts[1])});
        }
        return out;
    }

    private static String decode(String hexList) {
        StringBuilder sb = new StringBuilder();
        for (String h : hexList.trim().split(" ")) {
            if (h.length() == 0) continue;
            sb.appendCodePoint(Integer.parseInt(h, 16));
        }
        return sb.toString();
    }

    // ---------------------------------------------------------------- converter port

    static boolean isHalant(char c) { return c == HAS; }

    static boolean isPreKar(char c) { return c == '\u09BF' || c == '\u09C7' || c == '\u09C8'; }

    static boolean isBanjon(char c) {
        return (c >= '\u0995' && c <= '\u09B9') || c == '\u09DC' || c == '\u09DD'
                || c == '\u09DF' || c == '\u09CE';
    }

    private static char charAt(String s, int i) {
        return (i < 0 || i >= s.length()) ? '\0' : s.charAt(i);
    }

    /** JavaScript String.substring semantics (clamp, swap). */
    private static String sub(String s, int a, int b) {
        int n = s.length();
        a = Math.max(0, Math.min(a, n));
        b = Math.max(0, Math.min(b, n));
        if (a > b) { int t = a; a = b; b = t; }
        return s.substring(a, b);
    }

    static String rearrange(String s) {
        int last = 0;
        for (int i = 0; i < s.length(); i++) {
            if (isPreKar(s.charAt(i))) {
                int j = 1;
                while (isBanjon(charAt(s, i - j))) {
                    if (i - j < 0) break;
                    if (i - j <= last) break;
                    if (isHalant(charAt(s, i - j - 1))) j += 2; else break;
                }
                String t = sub(s, 0, i - j);
                t += s.charAt(i);
                t += sub(s, i - j, i);
                t += sub(s, i + 1, s.length());
                s = t;
                last = i + 1;
                continue;
            }
            if (i < s.length() - 1 && isHalant(s.charAt(i)) && charAt(s, i - 1) == RA
                    && !isHalant(charAt(s, i - 2))) {
                int j = 1;
                int flag = 0;
                while (true) {
                    if (isBanjon(charAt(s, i + j)) && isHalant(charAt(s, i + j + 1))) {
                        j += 2;
                    } else {
                        if (isBanjon(charAt(s, i + j)) && isPreKar(charAt(s, i + j + 1))) {
                            flag = 1;
                        }
                        break;
                    }
                }
                String t = sub(s, 0, i - 1);
                t += sub(s, i + j + 1, i + j + flag + 1);
                t += sub(s, i + 1, i + j + 1);
                t += s.charAt(i - 1);
                t += s.charAt(i);
                t += sub(s, i + j + flag + 1, s.length());
                s = t;
                i += (j + flag);
                last = i + 1;
                continue;
            }
        }
        return s;
    }

    /** Same as the website converter: Unicode text to Bijoy ASCII. */
    public String convert(String s) {
        s = s.replace("\u09CB", "\u09C7\u09BE");
        s = s.replace("\u09CC", "\u09C7\u09D7");
        s = rearrange(s);
        for (String[] kv : map) {
            s = s.replace(kv[0], kv[1]);
        }
        return s;
    }

    // ---------------------------------------------------------------- typing

    private static final int K_CONS = 1, K_HAS = 2, K_FOLA = 3, K_PRE = 4, K_POST = 5,
            K_MOD = 6, K_VOWEL = 7, K_LITERAL = 8;

    private static boolean isBangla(char c) {
        return (c >= '\u0980' && c <= '\u09FF') || c == '\u0964' || c == '\u0965';
    }

    private static int kind(String k) {
        char c = k.charAt(0);
        if (!isBangla(c)) return K_LITERAL;
        if (c == HAS) return k.length() >= 2 ? K_FOLA : K_HAS;
        if (isBanjon(c)) return K_CONS;
        if (isPreKar(c)) return K_PRE;
        if (c == '\u09BE' || c == '\u09C0' || c == '\u09C1' || c == '\u09C2' || c == '\u09C3'
                || c == '\u09D7' || c == '\u09CB' || c == '\u09CC') return K_POST;
        if (c == '\u0982' || c == '\u0983' || c == '\u0981') return K_MOD;
        if (c >= '\u0985' && c <= '\u0994') return K_VOWEL;
        return K_LITERAL;
    }

    /** hasanta + kar gives an independent vowel. */
    private static String independentVowel(String kar) {
        switch (kar.charAt(0)) {
            case '\u09BE': return "\u0986"; // aa
            case '\u09BF': return "\u0987"; // i
            case '\u09C0': return "\u0988"; // ii
            case '\u09C1': return "\u0989"; // u
            case '\u09C2': return "\u098A"; // uu
            case '\u09C3': return "\u098B"; // ri
            case '\u09C7': return "\u098F"; // e
            case '\u09C8': return "\u0990"; // oi
            case '\u09D7': return "\u0994"; // ou
            default: return null;
        }
    }

    private boolean endsWithHas() {
        return cluster.length() > 0 && cluster.charAt(cluster.length() - 1) == HAS;
    }

    private boolean endsWithLetter() {
        if (cluster.length() == 0) return false;
        char c = cluster.charAt(cluster.length() - 1);
        return isBanjon(c);
    }

    public String currentAscii() { return ascii; }

    public String peekInserted() {
        Snap s = history.peekLast();
        return s == null ? null : s.inserted;
    }

    public void reset() {
        pre = ""; cluster = ""; post = ""; ascii = ""; word = ""; left = "";
        history.clear();
    }

    private void flush() {
        String u = uniRender(pre, cluster, post);
        if (u.length() > 0) {
            word = word + u;
            if (word.length() > 40) word = word.substring(word.length() - 40);
        }
        if (ascii.length() > 0) left = ascii.substring(ascii.length() - 1);
        pre = ""; cluster = ""; post = ""; ascii = "";
    }

    /** Logical Unicode of a syllable (pre-kar placed after the consonants). */
    private static String uniRender(String pre, String cluster, String post) {
        String s;
        if (pre.equals("\u09C7") && post.startsWith("\u09BE")) {
            s = cluster + "\u09CB" + post.substring(1);
        } else if (pre.equals("\u09C7") && post.startsWith("\u09D7")) {
            s = cluster + "\u09CC" + post.substring(1);
        } else {
            s = cluster + pre + post;
        }
        if (cluster.equals("\u0985") && s.startsWith("\u0985\u09BE")) {
            s = "\u0986" + s.substring(2);
        }
        s = s.replace("\u09DC", "\u09A1\u09BC").replace("\u09DD", "\u09A2\u09BC")
                .replace("\u09DF", "\u09AF\u09BC");
        return s;
    }

    /** What the user is typing right now, as Unicode text (for the preview). */
    public String preview() {
        return word + uniRender(pre, cluster, post);
    }

    private String literalOut(String key) {
        if (unicodeMode) return key;
        if (isBangla(key.charAt(0))) return convert(key);
        for (String[] kv : map) {
            if (kv[0].equals(key)) return kv[1];
        }
        return key;
    }

    private String render() {
        if (unicodeMode) return uniRender(pre, cluster, post);
        StringBuilder sb = new StringBuilder();
        if (pre.length() > 0) sb.append(convert(pre));
        if (cluster.length() > 0 || post.length() > 0) sb.append(convert(cluster + post));
        return finishAscii(sb.toString());
    }

    /** Same as the website's finishingTouch(), applied with one character of left context. */
    private String finishAscii(String raw) {
        if (finish.isEmpty() || raw.length() == 0) return raw;
        String s = left + raw;
        for (String[] kv : finish) {
            s = s.replace(kv[0], kv[1]);
        }
        if (left.length() == 0 && s.length() > 0) {
            char c = s.charAt(0);
            if (c == '\u2021') s = "\u2020" + s.substring(1);
            else if (c == '\u2030') s = "\u02C6" + s.substring(1);
        }
        if (left.length() > 0) {
            if (!s.startsWith(left)) return raw;
            s = s.substring(left.length());
        }
        return s;
    }

    private boolean needsFlush(int k, String key) {
        boolean hasCl = cluster.length() > 0;
        boolean hasPost = post.length() > 0;
        boolean hasPre = pre.length() > 0;
        switch (k) {
            case K_CONS:
                if (hasCl) return !(endsWithHas() && !hasPost);
                return hasPost;
            case K_HAS:
                if (hasCl) return !(endsWithLetter() && !hasPost);
                return hasPre || hasPost;
            case K_FOLA:
                if (hasCl && !hasPost) return !(endsWithHas() || endsWithLetter());
                return true;
            case K_PRE:
                if (cluster.equals("" + HAS) && !hasPre && !hasPost) return false;
                if (!hasPre && !hasPost && (!hasCl || endsWithHas())) return false;
                return true;
            case K_POST:
                if (cluster.equals("" + HAS) && !hasPre && !hasPost
                        && independentVowel(key) != null) return false;
                if (hasCl) return false;
                return hasPre;
            case K_MOD:
                if (hasCl || hasPost) return false;
                return hasPre;
            case K_VOWEL:
            default:
                return true;
        }
    }

    private void apply(int k, String key) {
        switch (k) {
            case K_CONS:
                cluster = cluster + key;
                break;
            case K_HAS:
                cluster = cluster + key;
                break;
            case K_FOLA:
                if (endsWithHas()) cluster = cluster + key.substring(1);
                else cluster = cluster + key;
                break;
            case K_PRE: {
                String v = cluster.equals("" + HAS) && pre.length() == 0 ? independentVowel(key) : null;
                if (v != null) { cluster = v; } else { pre = key; }
                break;
            }
            case K_POST: {
                String v = cluster.equals("" + HAS) && pre.length() == 0 && post.length() == 0
                        ? independentVowel(key) : null;
                if (v != null) { cluster = v; } else { post = post + key; }
                break;
            }
            case K_MOD:
                post = post + key;
                break;
            case K_VOWEL:
                cluster = key;
                break;
            default:
                break;
        }
    }

    private void push(Snap h) {
        history.addLast(h);
        while (history.size() > MAX_HISTORY) history.pollFirst();
    }

    /** Handle one key. key is Bangla logical text (e.g. "\u0995") or a literal ASCII string. */
    public Edit onKey(String key) {
        Snap h = new Snap();
        h.pre = pre; h.cluster = cluster; h.post = post; h.ascii = ascii; h.word = word; h.left = left;
        int k = kind(key);
        if (k == K_LITERAL) {
            flush();
            String out = literalOut(key);
            if (key.equals(" ") || key.equals("\n") || key.equals("\r") || key.equals("\t")) {
                word = "";
            } else {
                word = word + key;
                if (word.length() > 40) word = word.substring(word.length() - 40);
            }
            if (out.length() > 0) left = out.substring(out.length() - 1);
            h.removed = "";
            h.inserted = out;
            push(h);
            return new Edit(0, out);
        }
        // consonant + hasanta + kar  =>  the hasanta was meant as the independent-vowel prefix
        if ((k == K_PRE || k == K_POST) && post.length() == 0 && cluster.length() > 1
                && endsWithHas() && independentVowel(key) != null) {
            String oldAscii = ascii;
            cluster = cluster.substring(0, cluster.length() - 1);
            String fixed = render();
            String vowel = independentVowel(key);
            String vowelAscii = unicodeMode ? vowel : convert(vowel);
            int cc = 0;
            int mm = Math.min(oldAscii.length(), fixed.length());
            while (cc < mm && oldAscii.charAt(cc) == fixed.charAt(cc)) cc++;
            String ins = fixed.substring(cc) + vowelAscii;
            h.removed = oldAscii.substring(cc);
            h.inserted = ins;
            ascii = fixed;
            flush();
            cluster = vowel;
            ascii = vowelAscii;
            push(h);
            return new Edit(oldAscii.length() - cc, ins);
        }
        if (needsFlush(k, key)) flush();
        String base = ascii;
        apply(k, key);
        String neu = render();
        int c = 0;
        int m = Math.min(base.length(), neu.length());
        while (c < m && base.charAt(c) == neu.charAt(c)) c++;
        h.removed = base.substring(c);
        h.inserted = neu.substring(c);
        ascii = neu;
        push(h);
        return new Edit(base.length() - c, neu.substring(c));
    }

    /** Undo the last key. Returns null when there is nothing to undo. */
    public Edit onBackspace() {
        Snap h = history.pollLast();
        if (h == null) return null;
        pre = h.pre; cluster = h.cluster; post = h.post; ascii = h.ascii; word = h.word; left = h.left;
        return new Edit(h.inserted.length(), h.removed);
    }
}
